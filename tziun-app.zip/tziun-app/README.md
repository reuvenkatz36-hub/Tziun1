# ציון | Tziun

> מערכת ניהול ציונים חכמה למורים בבתי ספר יסודיים

[![Next.js](https://img.shields.io/badge/Next.js-14-black?logo=next.js)](https://nextjs.org/)
[![Supabase](https://img.shields.io/badge/Supabase-DB-green?logo=supabase)](https://supabase.com/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)](https://www.typescriptlang.org/)

---

## ✨ פיצ'רים

- 📋 **ניהול מבחנים** - הזנת ציונים, משוב, תיוק אוטומטי
- 📓 **שיעורי בית** - הקלקה אחת לכל תלמיד, חישוב משוקלל אוטומטי
- 📈 **תיק תלמיד דיגיטלי** - גרפי התקדמות, מטריצת כישורים, היסטוריה
- 🎯 **ניתוח כיתתי** - איתור שאלות שהכיתה נכשלה בהן
- ✨ **בדיקת AI אוטומטית** - מובנה (Claude Sonnet 4.5 - דורש הפעלה)
- 👨‍👩‍👧 **דוחות הורים** - PDF מעוצב לשליחה בוואטסאפ
- 🔐 **פרטיות מלאה** - Row Level Security, אין שמירת ת"ז

---

## 🚀 התקנה מהירה

### 1. דרישות מקדימות
- Node.js 18+
- חשבון Supabase (חינם)
- חשבון Vercel (חינם)
- API key של Anthropic Claude (לAI - לא חובה להפעלה ראשונית)

### 2. Clone והתקנת תלויות
```bash
git clone https://github.com/reuvenkatz36-hub/Tziun.git
cd Tziun
npm install
```

### 3. הגדרת Supabase
1. צרו פרויקט חדש ב-[Supabase](https://supabase.com) (אזור: Frankfurt)
2. הריצו את `database/schema.sql` ב-SQL Editor
3. ב-Authentication > Providers - הפעילו Email + Google
4. ב-URL Configuration - הוסיפו: `http://localhost:3000/auth/callback` וגם את ה-URL של Vercel

### 4. משתני סביבה
צרו קובץ `.env.local`:
```bash
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_xxx
SUPABASE_SERVICE_ROLE_KEY=sb_secret_xxx
ANTHROPIC_API_KEY=sk-ant-xxx
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 5. הרצה מקומית
```bash
npm run dev
```

פתחו: http://localhost:3000

---

## 🌐 דיפלוי לפרודקשן

### Vercel (מומלץ)
1. Push לגיטהאב
2. חברו את הרפו ל-Vercel
3. הוסיפו את כל משתני הסביבה
4. Deploy!

ה-URL הנפרס יהיה: `https://tziun.vercel.app` (או שם משלכם)

עדכנו את `NEXT_PUBLIC_APP_URL` ל-URL הזה ב-Vercel ו-Supabase.

---

## 🏗️ ארכיטקטורה

```
tziun/
├── app/                  # Next.js App Router
│   ├── page.tsx          # דף נחיתה
│   ├── login/            # התחברות
│   ├── sales/            # תמחור
│   ├── onboarding/       # הקמת כיתה ראשונה
│   ├── app/              # דשבורד ראשי (אחרי login)
│   ├── students/         # תיקי תלמידים
│   ├── grade/[id]/       # הזנת מבחן
│   ├── homework/         # שיעורי בית
│   ├── analytics/[id]/   # ניתוח כיתתי
│   ├── settings/         # הגדרות
│   └── api/              # API routes
├── components/           # רכיבים משותפים
│   ├── shared/           # Topbar, lists
│   ├── grading/          # הזנת מבחן
│   └── analytics/        # גרפים
├── lib/
│   ├── supabase/         # DB clients
│   ├── ai/               # Claude AI
│   └── utils/            # פונקציות עזר
└── database/
    └── schema.sql        # PostgreSQL schema
```

---

## 💼 מודל עסקי

- **B2B SaaS** - מכירה ישירה לבתי ספר
- **תמחור** - 13.8K-24.5K ₪ לשנה (תלוי בגודל בית ספר)
- **תקציב** - מתאים לגפ"ן (פחות מ-25K)
- **AI כלול** - בכל החבילות

---

## 📜 רישיון

כל הזכויות שמורות © 2026 Tziun
