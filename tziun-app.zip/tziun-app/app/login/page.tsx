"use client";

import { createClient } from "@/lib/supabase/client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function SchoolLoginPage() {
  const supabase = createClient();
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [schoolName, setSchoolName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (mode === "signup") {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { school_name: schoolName },
            emailRedirectTo: `${location.origin}/auth/callback`
          }
        });
        if (signUpError) throw signUpError;
        if (data.user) {
          await supabase.from("schools").insert({
            id: data.user.id,
            school_email: email,
            school_name: schoolName,
            subscription_status: "trial"
          });
          router.push("/onboarding/school");
        }
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (signInError) throw signInError;
        router.push("/profiles");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{
      background: "linear-gradient(180deg, #FAF8F3 0%, #F4EFE3 100%)"
    }}>
      <div className="w-full max-w-md bg-white p-10 rounded-3xl shadow-lg-soft border border-line">
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-accent text-white rounded-2xl flex items-center justify-center font-display font-black text-2xl mx-auto mb-4 shadow-md-soft">
            צ
          </div>
          <h1 className="font-display text-2xl">
            {mode === "login" ? "כניסה לבית הספר" : "רישום בית ספר חדש"}
          </h1>
          <p className="text-ink-soft mt-2 text-sm">
            {mode === "login" ? "כניסה משותפת לכל מורות בית הספר" : "התחילו את תקופת הניסיון של 14 יום"}
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-700 text-sm mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {mode === "signup" && (
            <div className="mb-4">
              <label className="input-label">שם בית הספר</label>
              <input
                type="text"
                required
                placeholder="לדוגמה: בית ספר 'אופק' רעננה"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="input"
              />
            </div>
          )}
          <div className="mb-4">
            <label className="input-label">מייל בית הספר</label>
            <input
              type="email"
              required
              placeholder="school@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input"
              dir="ltr"
            />
          </div>
          <div className="mb-6">
            <label className="input-label">סיסמה</label>
            <input
              type="password"
              required
              minLength={6}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input"
              dir="ltr"
            />
            {mode === "signup" && (
              <p className="text-xs text-ink-soft mt-1">לפחות 6 תווים. תשתפו עם כל מורות בית הספר.</p>
            )}
          </div>
          <button type="submit" disabled={loading} className="btn btn-primary btn-block">
            {loading ? "..." : mode === "login" ? "כניסה" : "צרו חשבון ניסיון"}
          </button>
        </form>

        <div className="text-center mt-6 text-sm">
          {mode === "login" ? (
            <button onClick={() => setMode("signup")} className="text-accent font-semibold">
              בית ספר חדש? לחצו לרישום
            </button>
          ) : (
            <button onClick={() => setMode("login")} className="text-accent font-semibold">
              יש לכם כבר חשבון? התחברו
            </button>
          )}
        </div>

        <p className="text-center mt-4">
          <Link href="/" className="text-ink-soft text-sm hover:text-ink">← חזרה לדף הבית</Link>
        </p>
      </div>
    </div>
  );
}
