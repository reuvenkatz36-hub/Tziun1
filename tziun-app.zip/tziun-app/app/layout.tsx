import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ציון | Tziun - מערכת ניהול ציונים חכמה למורים",
  description: "מערכת AI לבדיקת מבחנים, מעקב תלמידים והפקת תובנות פדגוגיות לבתי ספר",
  manifest: "/manifest.json"
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#1B4D3E"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Assistant:wght@300;400;500;600;700;800&family=Frank+Ruhl+Libre:wght@500;700;900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans antialiased bg-paper text-ink min-h-screen">
        {children}
      </body>
    </html>
  );
}
