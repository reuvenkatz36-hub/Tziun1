import Link from "next/link";

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="min-h-screen flex flex-col" style={{
        background: "radial-gradient(ellipse at top right, rgba(201,169,97,0.08), transparent 50%), radial-gradient(ellipse at bottom left, rgba(27,77,62,0.05), transparent 50%), #FAF8F3"
      }}>
        {/* Topbar */}
        <header className="topbar">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent text-white rounded-xl flex items-center justify-center font-display font-black text-xl shadow-md-soft">צ</div>
              <div>
                <div className="font-display font-bold text-2xl">ציון</div>
                <div className="text-xs text-ink-soft opacity-60">Tziun</div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <Link href="/sales" className="btn btn-ghost">תמחור</Link>
              <Link href="/login" className="btn btn-secondary">התחברות</Link>
              <Link href="/login" className="btn btn-primary">התחילו עכשיו</Link>
            </div>
          </div>
        </header>

        {/* Hero content */}
        <div className="flex-1 flex items-center py-8">
          <div className="max-w-7xl mx-auto px-6 w-full">
            <div className="grid lg:grid-cols-[1.2fr_1fr] gap-16 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-accent-soft text-accent rounded-full text-sm font-semibold mb-6">
                  <span>●</span>
                  <span>מערכת ניהול ציונים חכמה לבתי ספר</span>
                </div>
                <h1 className="font-display font-black text-5xl md:text-6xl leading-tight tracking-tight mb-6">
                  פחות בירוקרטיה,<br/>
                  <em className="text-accent">יותר הוראה.</em>
                </h1>
                <p className="text-xl text-ink-soft leading-relaxed mb-8 max-w-xl">
                  ציון היא המערכת הראשונה שמרכזת ניהול מבחנים, שיעורי בית, ומעקב התלמיד הבודד —
                  הכל במקום אחד, נקי, חכם וקל. עם בדיקת AI אוטומטית מובנית.
                </p>
                <div className="flex gap-4 flex-wrap mb-12">
                  <Link href="/login" className="btn btn-primary btn-lg">צפו בהדגמה</Link>
                  <Link href="/sales" className="btn btn-secondary btn-lg">תוכניות תמחור</Link>
                </div>
                <div className="flex gap-8 pt-8 border-t border-line">
                  <div>
                    <div className="font-display text-3xl font-black text-accent">85%</div>
                    <div className="text-sm text-ink-soft">פחות זמן בדיקה</div>
                  </div>
                  <div>
                    <div className="font-display text-3xl font-black text-accent">100%</div>
                    <div className="text-sm text-ink-soft">פיקוח על תלמיד</div>
                  </div>
                  <div>
                    <div className="font-display text-3xl font-black text-accent">∞</div>
                    <div className="text-sm text-ink-soft">תיקים דיגיטליים</div>
                  </div>
                </div>
              </div>

              {/* Visual mockup */}
              <div className="aspect-[4/3] bg-white border border-line rounded-3xl shadow-lg-soft overflow-hidden p-8 flex flex-col gap-3" style={{ transform: "rotate(1deg)" }}>
                <div className="flex justify-between items-center mb-2">
                  <div className="font-display font-bold text-lg">כיתה ה'2 — מתמטיקה</div>
                  <div className="text-xs text-ink-soft">היום</div>
                </div>
                <MockRow name="דניאל לוי" initials="דל" color="#1B4D3E" score={92} progress={70} />
                <MockRow name="רוני נחום" initials="רנ" color="#C9A961" score={78} progress={55} />
                <MockRow name="יואב עזרא" initials="יע" color="#2D7560" score={95} progress={85} />
                <div className="mt-auto pt-4 border-t border-line flex justify-between text-sm text-ink-soft">
                  <span>ממוצע כיתה</span>
                  <span className="font-bold text-accent">86.3</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <section className="bg-white py-20 px-6 border-t border-line">
        <h2 className="font-display text-4xl font-bold text-center mb-4">הכל במקום אחד</h2>
        <p className="text-center text-ink-soft text-lg max-w-2xl mx-auto mb-16">
          מערכת אחת לכל מה שמורה צריכה — מבחנים, שיעורי בית, מעקב, וניתוח AI.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Feature icon="✨" title="בדיקת AI אוטומטית" desc="ה-AI בודק מבחנים מצולמים תוך שניות. ציון אוטומטי, משוב מותאם, מיפוי כישורים." />
          <Feature icon="📋" title="ניהול מבחנים" desc="הזנת ציונים, משוב, תיוק בתיק התלמיד. צפייה בכל המבחנים בגרף התקדמות." />
          <Feature icon="📓" title="שיעורי בית" desc="הקלקה אחת לכל תלמיד. מעקב יומי המתחבר לציון השנתי המשוקלל." />
          <Feature icon="📈" title="תיק תלמיד דיגיטלי" desc="פרופיל מלא — ציונים, מגמות, חוזקות, חולשות, ומטריצת כישורים." />
          <Feature icon="🎯" title="ניתוח כיתתי" desc="גלו אילו נושאים הכיתה לא הבינה. נתונים שמובילים להוראה חכמה." />
          <Feature icon="👨‍👩‍👧" title="דוחות להורים" desc="הפקת PDF מעוצב לכל תלמיד — מוכן לפגישת הורים או לוואטסאפ." />
        </div>
      </section>

      {/* Pricing preview */}
      <section className="py-20 px-6 bg-paper-warm">
        <h2 className="font-display text-4xl font-bold text-center mb-4">תמחור פשוט. בית ספר אחד, כל המורות.</h2>
        <p className="text-center text-ink-soft text-lg max-w-2xl mx-auto mb-12">
          מתאים לתקציב גפ"ן — אישור חד-פעמי, גישה לשנה שלמה. AI כלול בכל החבילות.
        </p>
        <div className="text-center">
          <Link href="/sales" className="btn btn-primary btn-lg">לצפייה בחבילות →</Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-ink text-white/70 text-center">
        <div className="font-display text-2xl text-white mb-2">ציון | Tziun</div>
        <div className="mb-6">מערכת ניהול ציונים חכמה לבתי ספר בישראל</div>
        <div className="text-sm opacity-60">© 2026 ציון · נבנה בישראל · contact@tziun.co.il</div>
      </footer>
    </div>
  );
}

function MockRow({ name, initials, color, score, progress }: any) {
  const grade = score >= 90 ? "grade-excellent" : score >= 75 ? "grade-good" : "grade-ok";
  return (
    <div className="flex items-center gap-4 p-3 bg-paper rounded-xl">
      <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ background: color }}>
        {initials}
      </div>
      <div className="flex-1">
        <div className="font-semibold text-sm">{name}</div>
        <div className="h-2 bg-line rounded-full mt-1 overflow-hidden">
          <div className="h-full bg-accent" style={{ width: `${progress}%` }}/>
        </div>
      </div>
      <div className={`grade-badge ${grade}`}>{score}</div>
    </div>
  );
}

function Feature({ icon, title, desc }: any) {
  return (
    <div className="p-8 bg-paper rounded-2xl border border-line hover:-translate-y-1 transition-transform hover:shadow-md-soft">
      <div className="text-3xl mb-4 w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm-soft">
        {icon}
      </div>
      <h3 className="font-display text-xl mb-2">{title}</h3>
      <p className="text-ink-soft">{desc}</p>
    </div>
  );
}
