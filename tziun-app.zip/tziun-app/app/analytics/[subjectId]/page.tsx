import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import Topbar from "@/components/shared/Topbar";

export default async function AnalyticsPage({ params }: { params: { subjectId: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: subject } = await supabase
    .from("subjects")
    .select("id, name, classes(name)")
    .eq("id", params.subjectId)
    .single();

  if (!subject) notFound();

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref={`/grade/${params.subjectId}`} title="📊 ניתוח כיתתי" subtitle={subject.name} showActions={false} />

      <main className="max-w-3xl mx-auto px-6 py-8">
        {/* Summary stats */}
        <div className="card mb-6" style={{
          background: "linear-gradient(135deg, #E8F2EE, white)"
        }}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="font-display text-2xl font-black">81.4</div>
              <div className="text-sm text-ink-soft">ממוצע כיתה</div>
            </div>
            <div>
              <div className="font-display text-2xl font-black text-success">96</div>
              <div className="text-sm text-ink-soft">ציון גבוה</div>
            </div>
            <div>
              <div className="font-display text-2xl font-black text-danger">52</div>
              <div className="text-sm text-ink-soft">ציון נמוך</div>
            </div>
            <div>
              <div className="font-display text-2xl font-black">28/28</div>
              <div className="text-sm text-ink-soft">נבדקו</div>
            </div>
          </div>
        </div>

        {/* Critical insight */}
        <div className="bg-red-50 border-r-4 border-danger rounded-2xl p-4 mb-6">
          <div className="font-semibold text-red-900 mb-1">⚠️ תובנה כיתתית חשובה</div>
          <div className="text-red-800 text-sm">
            <strong>71%</strong> מהכיתה נכשלו בשאלה 6 — חיבור שברים עם מכנה משותף.
            כדאי להעביר חזרה על הנושא בכיתה.
          </div>
        </div>

        <h3 className="font-display text-xl mb-4">פירוט שאלות</h3>

        <div className="space-y-3">
          <QuestionRow num={1} desc="חיבור בסיסי" correct={26} total={28} />
          <QuestionRow num={2} desc="שבר פשוט" correct={24} total={28} />
          <QuestionRow num={3} desc="שוויון שברים" correct={22} total={28} />
          <QuestionRow num={4} desc="המרת שבר עשרוני" correct={20} total={28} />
          <QuestionRow num={5} desc="שברים פשוטים" correct={19} total={28} />
          <QuestionRow num={6} desc="מכנה משותף" correct={8} total={28} critical />
          <QuestionRow num={7} desc="בעיה מילולית" correct={19} total={28} />
        </div>

        <p className="text-center text-ink-soft text-sm mt-8 italic">
          🤖 הנתונים יתעדכנו אוטומטית כשמערכת ה-AI תבדוק מבחנים חדשים
        </p>
      </main>
    </div>
  );
}

function QuestionRow({ num, desc, correct, total, critical }: any) {
  const pct = Math.round((correct / total) * 100);
  const color = pct >= 80 ? "bg-success" : pct >= 65 ? "bg-blue-500" : pct >= 50 ? "bg-amber" : "bg-danger";
  const textColor = pct >= 80 ? "text-success" : pct >= 65 ? "text-blue-700" : pct >= 50 ? "text-amber-700" : "text-danger";

  return (
    <div className={`card ${critical ? "border-2 border-danger bg-red-50" : ""}`}>
      <div className="flex justify-between items-start mb-3">
        <div>
          <div className={`font-semibold ${critical ? "text-red-900" : ""}`}>
            {critical && "⚠️ "}שאלה {num} — {desc}
          </div>
          <div className={`text-sm mt-1 ${critical ? "text-red-700" : "text-ink-soft"}`}>
            {correct} מתוך {total} ענו נכון
          </div>
        </div>
        <div className={`font-display text-2xl font-black ${textColor}`}>{pct}%</div>
      </div>
      <div className="h-2 bg-paper-warm rounded-full overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${pct}%` }}/>
      </div>
    </div>
  );
}
