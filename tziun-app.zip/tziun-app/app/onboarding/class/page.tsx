"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import Topbar from "@/components/shared/Topbar";

export default function ClassOnboardingPage() {
  const router = useRouter();
  const supabase = createClient();

  const [step, setStep] = useState(1);
  const [className, setClassName] = useState("");
  const [gradeLevel, setGradeLevel] = useState(5);
  const [studentsText, setStudentsText] = useState("");
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(["מתמטיקה"]);
  const [setAsHomeroom, setSetAsHomeroom] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [profileId, setProfileId] = useState("");

  useEffect(() => {
    const pid = localStorage.getItem("active_profile_id");
    if (!pid) { router.push("/profiles"); return; }
    setProfileId(pid);
  }, []);

  const allSubjects = [
    { name: "מתמטיקה", icon: "🔢" },
    { name: "עברית", icon: "📖" },
    { name: "תנ\"ך", icon: "📜" },
    { name: "מדעים", icon: "🔬" },
    { name: "אנגלית", icon: "🌍" },
    { name: "גיאוגרפיה", icon: "🗺️" }
  ];

  function toggleSubject(name: string) {
    setSelectedSubjects(prev =>
      prev.includes(name) ? prev.filter(s => s !== name) : [...prev, name]
    );
  }

  async function handleFinish() {
    setLoading(true);
    setError("");
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Create class
      const { data: newClass, error: classErr } = await supabase
        .from("classes")
        .insert({
          school_id: user.id,
          homeroom_teacher_id: setAsHomeroom ? profileId : null,
          name: className,
          grade_level: gradeLevel,
          school_year: "תשפ\"ו"
        })
        .select()
        .single();
      if (classErr) throw classErr;

      // If homeroom, mark profile
      if (setAsHomeroom) {
        await supabase.from("teacher_profiles").update({ is_homeroom_teacher: true }).eq("id", profileId);
      }

      // Add students
      const studentNames = studentsText.split("\n").map(s => s.trim()).filter(Boolean);
      if (studentNames.length > 0) {
        const { error: studErr } = await supabase
          .from("students")
          .insert(studentNames.map(name => ({ class_id: newClass.id, full_name: name })));
        if (studErr) throw studErr;
      }

      // Add subjects (taught by this teacher)
      const { error: subjErr } = await supabase
        .from("subjects")
        .insert(selectedSubjects.map(name => ({
          class_id: newClass.id,
          teacher_profile_id: profileId,
          name,
          icon: allSubjects.find(s => s.name === name)?.icon
        })));
      if (subjErr) throw subjErr;

      router.push("/app");
    } catch (e: any) {
      setError(e.message);
      setLoading(false);
    }
  }

  const studentCount = studentsText.split("\n").filter(s => s.trim()).length;

  return (
    <div className="min-h-screen bg-paper">
      <Topbar />
      <main className="max-w-xl mx-auto px-6 py-8">
        <div className="flex gap-2 mb-8">
          {[1, 2, 3].map(n => (
            <div key={n} className={`flex-1 h-1 rounded-full ${step >= n ? "bg-accent" : "bg-line"}`}/>
          ))}
        </div>

        <div className="text-ink-soft text-sm mb-2">שלב {step} מתוך 3</div>

        {step === 1 && (
          <>
            <h2 className="font-display text-3xl mb-2">בואו ניצור כיתה ראשונה</h2>
            <p className="text-ink-soft mb-8">תוכלו להוסיף עוד כיתות בכל עת.</p>
            <div className="card">
              <div className="mb-4">
                <label className="input-label">שם הכיתה</label>
                <input type="text" className="input" value={className} onChange={e => setClassName(e.target.value)}
                  placeholder="לדוגמה: כיתה ה'2" />
              </div>
              <div className="mb-4">
                <label className="input-label">שכבה</label>
                <select className="select" value={gradeLevel} onChange={e => setGradeLevel(Number(e.target.value))}>
                  {[1,2,3,4,5,6].map(n => <option key={n} value={n}>כיתה {["א'","ב'","ג'","ד'","ה'","ו'"][n-1]}</option>)}
                </select>
              </div>
              <label className="flex items-center gap-3 p-3 bg-paper rounded-xl cursor-pointer">
                <input type="checkbox" checked={setAsHomeroom} onChange={e => setSetAsHomeroom(e.target.checked)} className="w-5 h-5" />
                <div>
                  <div className="font-semibold text-sm">אני מחנכ/ת הכיתה הזו</div>
                  <div className="text-xs text-ink-soft">תקבלו גישה לכלי תעודות סוף שנה</div>
                </div>
              </label>
            </div>
            <button onClick={() => setStep(2)} disabled={!className} className="btn btn-primary btn-block btn-lg mt-6">
              המשך →
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <h2 className="font-display text-3xl mb-2">הוסיפו תלמידים</h2>
            <p className="text-ink-soft mb-8">הדביקו רשימת שמות, שורה לתלמיד.</p>
            <div className="card">
              <textarea className="input" rows={10} placeholder={"דניאל לוי\nרוני נחום\nיואב עזרא\n..."}
                value={studentsText} onChange={e => setStudentsText(e.target.value)} />
              <p className="text-xs text-ink-soft mt-2">💡 אפשר להעתיק רשימה ממשוב או אקסל</p>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setStep(1)} className="btn btn-secondary">חזרה</button>
              <button onClick={() => setStep(3)} disabled={studentCount === 0} className="btn btn-primary btn-block">
                המשך → ({studentCount} תלמידים)
              </button>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <h2 className="font-display text-3xl mb-2">איזה מקצועות אתם מלמדים?</h2>
            <p className="text-ink-soft mb-8">תוכלו להוסיף עוד מאוחר יותר.</p>
            <div className="grid grid-cols-2 gap-3">
              {allSubjects.map(s => {
                const selected = selectedSubjects.includes(s.name);
                return (
                  <button key={s.name} onClick={() => toggleSubject(s.name)}
                    className={`card card-hover text-right ${selected ? "border-accent bg-accent-soft" : ""}`}>
                    <div className="flex gap-3 items-center">
                      <input type="checkbox" checked={selected} readOnly className="w-5 h-5"/>
                      <div className="text-3xl">{s.icon}</div>
                      <div className="font-semibold">{s.name}</div>
                    </div>
                  </button>
                );
              })}
            </div>
            {error && <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-700 text-sm mt-4">{error}</div>}
            <div className="flex gap-3 mt-6">
              <button onClick={() => setStep(2)} className="btn btn-secondary">חזרה</button>
              <button onClick={handleFinish} disabled={loading || selectedSubjects.length === 0} className="btn btn-primary btn-block">
                {loading ? "יוצר..." : "סיים והתחל ✨"}
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
