"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import Topbar from "@/components/shared/Topbar";

export default function SchoolOnboardingPage() {
  const router = useRouter();
  const supabase = createClient();
  const [schoolName, setSchoolName] = useState("");
  const [city, setCity] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }
      const { data: school } = await supabase.from("schools").select("school_name, city").eq("id", user.id).single();
      if (school) {
        setSchoolName(school.school_name || "");
        setCity(school.city || "");
      }
    })();
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error: err } = await supabase
      .from("schools")
      .update({ school_name: schoolName, city })
      .eq("id", user.id);

    if (err) {
      setError(err.message);
      setLoading(false);
    } else {
      router.push("/profiles");
    }
  }

  return (
    <div className="min-h-screen bg-paper">
      <Topbar />
      <main className="max-w-xl mx-auto px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🏫</div>
          <h1 className="font-display text-3xl mb-2">ברוכים הבאים ל-ציון</h1>
          <p className="text-ink-soft">בואו נכיר את בית הספר</p>
        </div>

        {error && <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-700 text-sm mb-4">{error}</div>}

        <form onSubmit={handleSave} className="card">
          <div className="mb-4">
            <label className="input-label">שם בית הספר</label>
            <input type="text" required value={schoolName} onChange={(e) => setSchoolName(e.target.value)}
              placeholder="לדוגמה: בית ספר אופק רעננה" className="input" />
          </div>
          <div className="mb-6">
            <label className="input-label">עיר</label>
            <input type="text" value={city} onChange={(e) => setCity(e.target.value)}
              placeholder="לדוגמה: רעננה" className="input" />
          </div>
          <button type="submit" disabled={loading || !schoolName} className="btn btn-primary btn-block btn-lg">
            {loading ? "שומר..." : "המשך לבחירת פרופיל →"}
          </button>
        </form>

        <p className="text-center text-ink-soft text-sm mt-6">
          🎁 תקופת ניסיון של 14 יום - גישה מלאה לכל הפיצ'רים
        </p>
      </main>
    </div>
  );
}
