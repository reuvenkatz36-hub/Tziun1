import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");

  if (code) {
    const supabase = createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: existingSchool } = await supabase
          .from("schools")
          .select("id")
          .eq("id", user.id)
          .single();

        if (!existingSchool) {
          // First-time school registration
          await supabase.from("schools").insert({
            id: user.id,
            school_email: user.email!,
            school_name: user.user_metadata?.school_name || "בית ספר חדש",
            subscription_status: "trial"
          });
          return NextResponse.redirect(`${origin}/onboarding/school`);
        }
        return NextResponse.redirect(`${origin}/profiles`);
      }
    }
  }

  return NextResponse.redirect(`${origin}/login?error=auth_failed`);
}
