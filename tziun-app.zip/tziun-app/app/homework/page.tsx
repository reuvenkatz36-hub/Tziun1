import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Topbar from "@/components/shared/Topbar";
import HomeworkLogger from "@/components/grading/HomeworkLogger";

export default async function HomeworkPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: classes } = await supabase
    .from("classes")
    .select("id, name")
    .eq("school_id", user.id)
    .limit(1);

  if (!classes || classes.length === 0) redirect("/onboarding/class");

  const { data: students } = await supabase
    .from("students")
    .select("id, full_name")
    .eq("class_id", classes[0].id)
    .order("full_name");

  const { data: subjects } = await supabase
    .from("subjects")
    .select("id, name")
    .eq("class_id", classes[0].id);

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref="/app" title="📓 שיעורי בית" subtitle={classes[0].name} showActions={false} />
      <main className="max-w-4xl mx-auto px-6 py-8">
        <HomeworkLogger students={students ?? []} subjects={subjects ?? []} />
      </main>
    </div>
  );
}
