import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import ProfilesSelector from "@/components/auth/ProfilesSelector";

export default async function ProfilesPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: school } = await supabase
    .from("schools")
    .select("id, school_name")
    .eq("id", user.id)
    .single();

  if (!school) redirect("/onboarding/school");

  const { data: profiles } = await supabase
    .from("teacher_profiles")
    .select("id, full_name, gender, avatar_color, is_homeroom_teacher")
    .eq("school_id", user.id)
    .order("created_at", { ascending: true });

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{
      background: "radial-gradient(ellipse at top, rgba(27,77,62,0.04), transparent 60%), #FAF8F3"
    }}>
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-accent text-white rounded-xl flex items-center justify-center font-display font-black text-xl shadow-md-soft">צ</div>
            <span className="font-display text-2xl">{school.school_name}</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl mb-3">מי משתמש/ת עכשיו?</h1>
          <p className="text-ink-soft">בחרו את הפרופיל שלכם או הוסיפו חדש</p>
        </div>

        <ProfilesSelector profiles={profiles ?? []} schoolId={user.id} />
      </div>
    </div>
  );
}
