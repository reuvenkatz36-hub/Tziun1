import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Topbar from "@/components/shared/Topbar";
import StudentSearchList from "@/components/shared/StudentSearchList";

export default async function StudentsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: classes } = await supabase
    .from("classes")
    .select("id, name")
    .eq("school_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1);

  if (!classes || classes.length === 0) redirect("/onboarding/class");

  const { data: students } = await supabase
    .from("students")
    .select("id, full_name, exams(total_score)")
    .eq("class_id", classes[0].id)
    .order("full_name");

  const enriched = (students ?? []).map((s: any) => {
    const scores = (s.exams ?? []).map((e: any) => e.total_score).filter(Boolean);
    const avg = scores.length ? Math.round(scores.reduce((a: number, b: number) => a + b, 0) / scores.length) : 0;
    return { id: s.id, full_name: s.full_name, examCount: scores.length, avg };
  });

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref="/app" title="תיקי תלמידים" subtitle={`${students?.length || 0} תלמידים`} showActions={false} />
      <main className="max-w-4xl mx-auto px-6 py-8">
        <StudentSearchList students={enriched} />
      </main>
    </div>
  );
}
