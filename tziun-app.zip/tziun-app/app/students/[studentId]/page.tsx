import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import Topbar from "@/components/shared/Topbar";
import StudentChart from "@/components/analytics/StudentChart";
import SkillMatrix from "@/components/analytics/SkillMatrix";
import WhatsAppShareButton from "@/components/grading/WhatsAppShareButton";
import { getInitials, getAvatarColor, getGradeColor } from "@/lib/utils";

export default async function StudentFolderPage({ params }: { params: { studentId: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("id, full_name, parent_phone, class_id, classes(name)")
    .eq("id", params.studentId)
    .single();

  if (!student) notFound();

  const { data: exams } = await supabase
    .from("exams")
    .select("id, exam_name, exam_date, total_score, subjects(name)")
    .eq("student_id", params.studentId)
    .order("exam_date", { ascending: false });

  const scores = (exams ?? []).map((e: any) => e.total_score).filter(Boolean);
  const examAvg = scores.length ? Math.round(scores.reduce((a: number, b: number) => a + b, 0) / scores.length) : 0;
  const hwScore = 95;
  const weightedScore = Math.round(examAvg * 0.7 + hwScore * 0.3);

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref="/students" title={student.full_name} subtitle={(student.classes as any)?.name} showActions={false} />

      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="relative overflow-hidden bg-white border border-line rounded-3xl mb-6">
          <div className="h-24 bg-gradient-to-l from-accent to-accent-bright"></div>
          <div className="px-8 pb-8 -mt-10 relative">
            <div className="w-20 h-20 rounded-full bg-white border-4 border-white shadow-md-soft flex items-center justify-center text-2xl font-bold mb-4"
              style={{ color: getAvatarColor(student.full_name) }}>
              {getInitials(student.full_name)}
            </div>
            <h1 className="font-display text-3xl">{student.full_name}</h1>
            <p className="text-ink-soft">{exams?.length || 0} מבחנים השנה</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <StatCard label="ממוצע מבחנים" value={examAvg || "-"} color="accent" />
          <StatCard label="שיעורי בית" value={hwScore} color="success" />
          <StatCard label="משוקלל" value={weightedScore || "-"} color="gold" sub="70/30" />
        </div>

        {exams && exams.length > 0 && (
          <div className="card mb-6">
            <h3 className="font-semibold mb-4">📈 קו התקדמות</h3>
            <StudentChart exams={exams} />
          </div>
        )}

        <div className="card mb-6">
          <h3 className="font-semibold mb-4">🎯 מטריצת כישורים</h3>
          <SkillMatrix studentId={params.studentId} />
        </div>

        <div className="card mb-6">
          <h3 className="font-display text-xl mb-4">📚 מבחנים אחרונים</h3>
          {exams && exams.length > 0 ? (
            <div className="space-y-3">
              {exams.slice(0, 10).map((e: any) => (
                <div key={e.id} className="flex items-center gap-4 py-3 border-b border-line last:border-0">
                  <div className="flex-1">
                    <div className="font-semibold">{e.exam_name || "מבחן"}</div>
                    <div className="text-sm text-ink-soft">
                      {new Date(e.exam_date).toLocaleDateString("he-IL")}
                      {e.subjects && ` · ${e.subjects.name}`}
                    </div>
                  </div>
                  <div className={`grade-badge ${getGradeColor(e.total_score)}`}>{e.total_score}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-ink-soft text-center py-8">אין מבחנים עדיין</p>
          )}
        </div>

        <div className="card">
          <h3 className="font-semibold mb-4">📤 שיתוף עם הורה</h3>
          <WhatsAppShareButton
            studentName={student.full_name}
            parentPhone={student.parent_phone}
            teacherName="המורה"
            teacherGender="female"
            totalScore={exams?.[0]?.total_score}
            examName={exams?.[0]?.exam_name}
          />
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value, color, sub }: any) {
  const colors: any = { accent: "text-accent", success: "text-success", gold: "text-gold" };
  return (
    <div className="card text-center">
      <div className={`font-display text-4xl font-black leading-none mb-2 ${colors[color]}`}>{value}</div>
      <div className="text-sm text-ink-soft">{label}</div>
      {sub && <div className="text-xs text-ink-soft mt-1">{sub}</div>}
    </div>
  );
}
