import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Topbar from "@/components/shared/Topbar";
import SettingsClient from "@/components/shared/SettingsClient";

export default async function SettingsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: school } = await supabase
    .from("schools")
    .select("school_name, school_email, city, subscription_status, subscription_ends_at, package_tier")
    .eq("id", user.id)
    .single();

  const { data: profiles } = await supabase
    .from("teacher_profiles")
    .select("id, full_name, gender, is_homeroom_teacher, last_active_at")
    .eq("school_id", user.id);

  const { data: classes } = await supabase
    .from("classes")
    .select("id, name, students(count), subjects(count)")
    .eq("school_id", user.id);

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref="/app" title="⚙️ הגדרות" showActions={false} />
      <main className="max-w-2xl mx-auto px-6 py-8">
        <SettingsClient school={school} profiles={profiles ?? []} classes={classes ?? []} />
      </main>
    </div>
  );
}
