import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import Topbar from "@/components/shared/Topbar";
import ManualExamEntry from "@/components/grading/ManualExamEntry";
import AIExamScanner from "@/components/grading/AIExamScanner";

export default async function SubjectPage({ params, searchParams }: { params: { subjectId: string }; searchParams: { mode?: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: subject } = await supabase
    .from("subjects")
    .select("id, name, class_id, classes(name, school_id)")
    .eq("id", params.subjectId)
    .single();

  if (!subject) notFound();

  // Manual entry mode
  if (searchParams.mode === "manual") {
    const { data: students } = await supabase
      .from("students")
      .select("id, full_name")
      .eq("class_id", subject.class_id)
      .order("full_name");

    return (
      <div className="min-h-screen bg-paper">
        <Topbar showBack backHref={`/grade/${subject.id}`} title="הזנה ידנית" subtitle={subject.name} showActions={false} />
        <main className="max-w-2xl mx-auto px-6 py-8">
          <ManualExamEntry subjectId={subject.id} students={students ?? []} />
        </main>
      </div>
    );
  }

  // AI scanning mode
  if (searchParams.mode === "ai") {
    const { data: students } = await supabase
      .from("students")
      .select("id, full_name")
      .eq("class_id", subject.class_id)
      .order("full_name");

    return (
      <div className="min-h-screen bg-paper">
        <Topbar showBack backHref={`/grade/${subject.id}`} title="✨ בדיקת AI" subtitle={subject.name} showActions={false} />
        <main className="max-w-2xl mx-auto px-6 py-8">
          <AIExamScanner subjectId={subject.id} students={students ?? []} />
        </main>
      </div>
    );
  }

  // List exams for this subject
  const { data: exams } = await supabase
    .from("exams")
    .select("id, exam_name, exam_date, total_score, student_id")
    .eq("subject_id", params.subjectId)
    .order("exam_date", { ascending: false })
    .limit(20);

  const grouped = new Map<string, { name: string, date: string, scores: number[] }>();
  for (const e of exams ?? []) {
    const key = e.exam_name || `מבחן ${e.exam_date}`;
    if (!grouped.has(key)) grouped.set(key, { name: key, date: e.exam_date, scores: [] });
    if (e.total_score) grouped.get(key)!.scores.push(e.total_score);
  }
  const examGroups = Array.from(grouped.values());

  return (
    <div className="min-h-screen bg-paper">
      <Topbar showBack backHref="/app" title={`${getIcon(subject.name)} ${subject.name}`} subtitle={(subject.classes as any)?.name} showActions={false} />

      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="grid md:grid-cols-2 gap-3 mb-8">
          <Link href={`/grade/${subject.id}?mode=ai`} className="btn btn-primary btn-lg">
            ✨ בדיקת AI אוטומטית
          </Link>
          <Link href={`/grade/${subject.id}?mode=manual`} className="btn btn-secondary btn-lg">
            📝 הזנה ידנית
          </Link>
        </div>

        <Link href={`/analytics/${subject.id}`} className="block card card-hover mb-8 flex items-center gap-4">
          <div className="text-3xl">📊</div>
          <div className="flex-1">
            <h4 className="font-semibold">ניתוח כיתתי</h4>
            <p className="text-sm text-ink-soft">צפו באיזה נושאים הכיתה לא הצליחה</p>
          </div>
          <div className="text-accent">←</div>
        </Link>

        <h3 className="font-display text-xl mb-4">מבחנים אחרונים</h3>

        {examGroups.length === 0 ? (
          <div className="card text-center py-12">
            <div className="text-5xl mb-4 opacity-50">📋</div>
            <p className="text-ink-soft mb-4">עוד אין מבחנים</p>
            <Link href={`/grade/${subject.id}?mode=ai`} className="btn btn-primary">
              סרקו מבחן ראשון עם AI
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {examGroups.map((g, i) => {
              const avg = g.scores.length ? Math.round(g.scores.reduce((a, b) => a + b, 0) / g.scores.length) : 0;
              return (
                <div key={i} className="card flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{g.name}</div>
                    <div className="text-sm text-ink-soft">
                      {new Date(g.date).toLocaleDateString("he-IL")} · {g.scores.length} תלמידים
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="font-display text-2xl font-black text-accent leading-none">{avg}</div>
                    <div className="text-xs text-ink-soft">ממוצע</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

function getIcon(name: string): string {
  if (name.includes("מתמטיקה")) return "🔢";
  if (name.includes("עברית")) return "📖";
  if (name.includes("תנ")) return "📜";
  if (name.includes("מדע")) return "🔬";
  if (name.includes("אנגלית")) return "🌍";
  return "📚";
}
