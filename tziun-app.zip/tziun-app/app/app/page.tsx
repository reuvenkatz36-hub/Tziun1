import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import DashboardClient from "@/components/shared/DashboardClient";

export default async function AppDashboard() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Get school info
  const { data: school } = await supabase
    .from("schools")
    .select("school_name, subscription_status, subscription_ends_at")
    .eq("id", user.id)
    .single();

  if (!school) redirect("/onboarding/school");

  // Get all classes for this school
  const { data: classes } = await supabase
    .from("classes")
    .select("id, name, grade_level, students(count), subjects(count)")
    .eq("school_id", user.id)
    .order("created_at", { ascending: false });

  return <DashboardClient school={school} classes={classes ?? []} schoolId={user.id} />;
}
