import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

export default async function SuperAdminPage() {
  // Use service role to bypass RLS
  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const [{ data: schools }, { data: profiles }, { data: usage }, { data: recentExams }] = await Promise.all([
    admin.from("schools").select("id, school_name, school_email, city, subscription_status, created_at"),
    admin.from("teacher_profiles").select("id, school_id, full_name, last_active_at"),
    admin.from("ai_scan_usage").select("school_id, student_id, scan_count, scan_month").order("scan_month", { ascending: false }).limit(100),
    admin.from("exams").select("id, exam_date, was_ai_graded, total_score").order("created_at", { ascending: false }).limit(20)
  ]);

  const totalAIScans = (usage ?? []).reduce((sum, u) => sum + u.scan_count, 0);
  const estimatedCost = (totalAIScans * 0.041).toFixed(2);

  return (
    <div className="min-h-screen bg-paper p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="font-display text-4xl mb-2">🛡️ Super Admin Dashboard</h1>
        <p className="text-ink-soft mb-8">פיקוח על כל בתי הספר במערכת</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Stat label="בתי ספר" value={schools?.length || 0} />
          <Stat label="פרופילי מורות" value={profiles?.length || 0} />
          <Stat label="סריקות AI סה״כ" value={totalAIScans} />
          <Stat label="עלות AI מוערכת" value={`$${estimatedCost}`} />
        </div>

        <div className="card mb-6">
          <h2 className="font-display text-2xl mb-4">בתי ספר רשומים</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-line">
                <tr className="text-right">
                  <th className="pb-2">שם</th>
                  <th className="pb-2">מייל</th>
                  <th className="pb-2">עיר</th>
                  <th className="pb-2">סטטוס</th>
                  <th className="pb-2">מורות</th>
                  <th className="pb-2">נרשם</th>
                </tr>
              </thead>
              <tbody>
                {(schools ?? []).map((s: any) => {
                  const profileCount = profiles?.filter((p: any) => p.school_id === s.id).length || 0;
                  return (
                    <tr key={s.id} className="border-b border-line">
                      <td className="py-2 font-semibold">{s.school_name}</td>
                      <td className="py-2 text-xs">{s.school_email}</td>
                      <td className="py-2">{s.city || "-"}</td>
                      <td className="py-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          s.subscription_status === "active" ? "bg-green-100 text-green-700" :
                          s.subscription_status === "trial" ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                        }`}>
                          {s.subscription_status === "active" ? "פעיל" : s.subscription_status === "trial" ? "ניסיון" : "לא פעיל"}
                        </span>
                      </td>
                      <td className="py-2 text-center">{profileCount}</td>
                      <td className="py-2 text-xs">{new Date(s.created_at).toLocaleDateString("he-IL")}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <h2 className="font-display text-2xl mb-4">פעילות AI אחרונה</h2>
          <p className="text-sm text-ink-soft mb-3">
            עלות חודשית מוערכת: <strong className="text-accent">${estimatedCost}</strong>
          </p>
          <div className="text-xs text-ink-soft">
            $0.041 פר סריקה · {totalAIScans} סריקות סה״כ
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: any }) {
  return (
    <div className="card text-center">
      <div className="font-display text-3xl font-black text-accent">{value}</div>
      <div className="text-sm text-ink-soft mt-1">{label}</div>
    </div>
  );
}
