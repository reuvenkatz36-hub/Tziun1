import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();

  const { data, error } = await supabase.from("exams").insert({
    student_id: body.student_id,
    subject_id: body.subject_id,
    graded_by_profile_id: body.graded_by_profile_id,
    exam_name: body.exam_name,
    exam_date: new Date().toISOString().split("T")[0],
    total_score: body.total_score,
    teacher_notes: body.teacher_notes,
    was_ai_graded: false,
    was_manual_fallback: body.was_manual_fallback || false,
    status: "graded",
    graded_at: new Date().toISOString()
  }).select().single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ success: true, exam: data });
}
