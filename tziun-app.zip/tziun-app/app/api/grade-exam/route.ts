import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { gradeExamWithClaude, checkAIQuota, incrementAIScan } from "@/lib/ai/claude";

export const maxDuration = 60;

export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const formData = await request.formData();
    const image = formData.get("image") as File;
    const studentId = formData.get("studentId") as string;
    const subjectId = formData.get("subjectId") as string;
    const teacherProfileId = formData.get("teacherProfileId") as string;
    const examName = formData.get("examName") as string;

    if (!image || !studentId || !subjectId || !teacherProfileId) {
      return NextResponse.json({ error: "חסרים נתונים נדרשים" }, { status: 400 });
    }

    // Validate image format and size
    if (!["image/jpeg", "image/png"].includes(image.type)) {
      return NextResponse.json({ error: "רק קבצי JPG ו-PNG נתמכים" }, { status: 400 });
    }
    if (image.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: "התמונה גדולה מ-5MB" }, { status: 400 });
    }

    // Check quota
    const quota = await checkAIQuota(studentId);
    if (!quota.allowed) {
      return NextResponse.json({
        error: "QUOTA_EXCEEDED",
        message: `התלמיד הזה הגיע למכסה של ${quota.max} סריקות בחודש זה`,
        current: quota.current,
        max: quota.max
      }, { status: 429 });
    }

    // Get context: student, subject, teacher profile
    const [{ data: student }, { data: subject }, { data: teacher }] = await Promise.all([
      supabase.from("students").select("full_name, class_id, classes(school_id, grade_level)").eq("id", studentId).single(),
      supabase.from("subjects").select("name").eq("id", subjectId).single(),
      supabase.from("teacher_profiles").select("full_name, gender").eq("id", teacherProfileId).single()
    ]);

    if (!student || !subject || !teacher) {
      return NextResponse.json({ error: "נתוני קונטקסט חסרים" }, { status: 404 });
    }

    // Convert image to base64
    const arrayBuffer = await image.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString("base64");

    // Call Claude
    const result = await gradeExamWithClaude({
      imageBase64: base64,
      subject: subject.name,
      gradeLevel: (student.classes as any)?.grade_level,
      studentName: student.full_name,
      teacherName: teacher.full_name,
      teacherGender: teacher.gender as "male" | "female"
    });

    // If illegible - return uncertainty without saving
    if (!result.is_legible || result.confidence === "uncertain") {
      return NextResponse.json({
        success: false,
        needsManualFallback: true,
        message: "כתב היד לא ברור מספיק. אנא הזן/י את הציון ידנית.",
        result
      });
    }

    // Increment quota
    const schoolId = (student.classes as any)?.school_id;
    await incrementAIScan(schoolId, studentId, teacherProfileId);

    // Save exam to database
    const { data: exam, error: examError } = await supabase
      .from("exams")
      .insert({
        student_id: studentId,
        subject_id: subjectId,
        graded_by_profile_id: teacherProfileId,
        exam_name: examName || "מבחן",
        exam_date: new Date().toISOString().split("T")[0],
        total_score: result.total_score,
        ai_suggested_score: result.total_score,
        ai_confidence: result.confidence,
        was_ai_graded: true,
        was_manual_fallback: false,
        status: "pending_review",
        bottom_line: result.bottom_line
      })
      .select()
      .single();

    if (examError) throw examError;

    // Save questions
    if (result.questions?.length) {
      await supabase.from("exam_questions").insert(
        result.questions.map(q => ({
          exam_id: exam.id,
          question_number: q.question_number,
          question_text: q.question_text,
          student_answer: q.student_answer,
          correct_answer: q.correct_answer,
          max_points: q.max_points,
          points_awarded: q.points_awarded,
          ai_feedback: q.ai_feedback,
          is_correct: q.is_correct,
          skill_tags: q.skill_tags
        }))
      );
    }

    return NextResponse.json({
      success: true,
      exam,
      result,
      quotaRemaining: quota.max - quota.current - 1
    });
  } catch (err: any) {
    console.error("Grading error:", err);
    return NextResponse.json({
      error: err.message || "שגיאה בבדיקת המבחן"
    }, { status: 500 });
  }
}
