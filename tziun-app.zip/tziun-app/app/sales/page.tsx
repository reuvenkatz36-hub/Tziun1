import Link from "next/link";

export default function SalesPage() {
  return (
    <div className="min-h-screen bg-paper-warm">
      <header className="topbar">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent text-white rounded-xl flex items-center justify-center font-display font-black text-xl">צ</div>
            <div>
              <div className="font-display font-bold text-2xl">ציון</div>
            </div>
          </Link>
          <div className="flex gap-2">
            <Link href="/" className="btn btn-ghost">דף הבית</Link>
            <Link href="/login" className="btn btn-primary">התחילו</Link>
          </div>
        </div>
      </header>

      <main className="py-16 px-6">
        <h1 className="font-display text-4xl md:text-5xl font-bold text-center mb-4">תמחור פשוט וברור</h1>
        <p className="text-center text-ink-soft text-lg max-w-2xl mx-auto mb-12">
          בית ספר אחד · כל המורות · AI מובנה · אין הגבלות
        </p>

        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <PricingCard
            name="🌱 ניצן"
            students="עד 250 תלמידים"
            price="13,800"
            features={[
              "גישה לכל המורות",
              "בדיקת AI אוטומטית מובנית",
              "ללא הגבלת מבחנים",
              "תיק דיגיטלי לכל תלמיד",
              "ניתוח כיתתי",
              "דוחות הורים",
              "תמיכה בעברית"
            ]}
          />
          <PricingCard
            name="🌳 אלון"
            students="250-500 תלמידים"
            price="19,800"
            featured
            features={[
              "כל מה שכלול ב\"ניצן\"",
              "דשבורד למנהל בית הספר",
              "השוואה בין כיתות",
              "גיבוי יומי",
              "אינטגרציה עם משוב",
              "תמיכת VIP",
              "הטמעה מלאה"
            ]}
          />
          <PricingCard
            name="🌟 עץ הדעת"
            students="500-1000 תלמידים"
            price="24,500"
            features={[
              "כל מה שכלול ב\"אלון\"",
              "API מותאם אישית",
              "מנהל הצלחה ייעודי",
              "סדנת הטמעה במקום",
              "גיבוי לפי דרישה",
              "SLA מובטח",
              "פיתוחים מותאמים"
            ]}
          />
        </div>

        <div className="max-w-2xl mx-auto mt-12 text-center p-8 bg-white rounded-2xl border border-line">
          <h3 className="font-display text-2xl mb-2">💚 מתאים לתקציב גפ"ן</h3>
          <p className="text-ink-soft">
            כל החבילות מתחת ל-25,000₪ ולכן לא דורשות אישור הקצאה מיוחד.
            תהליך מהיר וקל למנהלי בתי ספר.
          </p>
        </div>
      </main>
    </div>
  );
}

function PricingCard({ name, students, price, features, featured }: any) {
  return (
    <div className={`bg-white p-8 rounded-3xl border ${featured ? "border-accent shadow-lg-soft scale-[1.02]" : "border-line"} relative`}>
      {featured && (
        <div className="absolute -top-3 right-6 bg-accent text-white px-4 py-1 rounded-full text-xs font-semibold">
          הכי פופולרי
        </div>
      )}
      <div className="font-display text-2xl mb-1">{name}</div>
      <div className="text-ink-soft text-sm mb-6">{students}</div>
      <div className="font-display text-5xl font-black text-accent leading-none">{price}₪</div>
      <div className="text-ink-soft mt-2 mb-6">לשנה / כל המורות</div>
      <ul className="space-y-2 mb-8">
        {features.map((f: string, i: number) => (
          <li key={i} className="flex items-start gap-2 text-sm">
            <span className="text-accent font-bold flex-shrink-0">✓</span>
            <span>{f}</span>
          </li>
        ))}
      </ul>
      <Link href="/login" className={`btn ${featured ? "btn-primary" : "btn-secondary"} btn-block`}>
        דברו איתנו
      </Link>
    </div>
  );
}
