import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Assistant", "system-ui", "sans-serif"],
        display: ["Frank Ruhl Libre", "Georgia", "serif"]
      },
      colors: {
        ink: { DEFAULT: "#0F1419", soft: "#2C3E50" },
        paper: { DEFAULT: "#FAF8F3", warm: "#F4EFE3" },
        line: "#E8E2D4",
        accent: { DEFAULT: "#1B4D3E", bright: "#2D7560", soft: "#E8F2EE" },
        gold: "#C9A961",
        danger: { DEFAULT: "#B23A48", soft: "#F5E1E4" },
        amber: { DEFAULT: "#D97706", soft: "#FEF3C7" },
        success: "#15803D"
      },
      boxShadow: {
        'sm-soft': '0 1px 2px rgba(15,20,25,0.04), 0 1px 3px rgba(15,20,25,0.06)',
        'md-soft': '0 4px 6px -1px rgba(15,20,25,0.05), 0 2px 4px -1px rgba(15,20,25,0.04)',
        'lg-soft': '0 10px 25px -5px rgba(15,20,25,0.08), 0 8px 10px -6px rgba(15,20,25,0.05)'
      }
    }
  },
  plugins: []
};

export default config;
