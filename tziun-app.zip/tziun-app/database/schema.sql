-- ============================================
-- Tziun - Updated Schema (PRD v2)
-- Architecture: School → Teacher Profiles → Classes
-- ============================================

-- SCHOOLS (the actual paying customer)
CREATE TABLE IF NOT EXISTS schools (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  school_name TEXT NOT NULL,
  school_email TEXT NOT NULL UNIQUE,
  city TEXT,
  package_tier TEXT DEFAULT 'nitzan' CHECK (package_tier IN ('nitzan', 'alon', 'ets_hadaat')),
  max_students INT DEFAULT 250,
  subscription_status TEXT DEFAULT 'trial' CHECK (subscription_status IN ('trial', 'active', 'suspended', 'cancelled')),
  subscription_starts_at TIMESTAMPTZ DEFAULT NOW(),
  subscription_ends_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TEACHER PROFILES (Netflix-style)
CREATE TABLE IF NOT EXISTS teacher_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  gender TEXT NOT NULL CHECK (gender IN ('male', 'female')),
  avatar_color TEXT DEFAULT '#1B4D3E',
  is_homeroom_teacher BOOLEAN DEFAULT false,
  last_active_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- CLASSES
CREATE TABLE IF NOT EXISTS classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  homeroom_teacher_id UUID REFERENCES teacher_profiles(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  grade_level INT,
  school_year TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SUBJECTS
CREATE TABLE IF NOT EXISTS subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  teacher_profile_id UUID NOT NULL REFERENCES teacher_profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  icon TEXT,
  exam_weight DECIMAL(3,2) DEFAULT 0.70,
  homework_weight DECIMAL(3,2) DEFAULT 0.30,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- STUDENTS
CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  display_id TEXT,
  parent_phone TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- EXAMS
CREATE TABLE IF NOT EXISTS exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  graded_by_profile_id UUID REFERENCES teacher_profiles(id),
  exam_name TEXT,
  exam_date DATE NOT NULL,
  total_score INT,
  ai_suggested_score INT,
  ai_confidence TEXT CHECK (ai_confidence IN ('high', 'medium', 'low', 'uncertain')),
  was_ai_graded BOOLEAN DEFAULT false,
  was_manual_fallback BOOLEAN DEFAULT false,
  status TEXT DEFAULT 'pending',
  bottom_line TEXT,
  teacher_notes TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  graded_at TIMESTAMPTZ
);

-- EXAM QUESTIONS
CREATE TABLE IF NOT EXISTS exam_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  question_number INT NOT NULL,
  question_text TEXT,
  student_answer TEXT,
  correct_answer TEXT,
  max_points INT,
  points_awarded INT,
  ai_feedback TEXT,
  teacher_feedback TEXT,
  is_correct BOOLEAN,
  skill_tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- HOMEWORK LOGS
CREATE TABLE IF NOT EXISTS homework_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  logged_by_profile_id UUID REFERENCES teacher_profiles(id),
  log_date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('full', 'partial', 'missing')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, subject_id, log_date)
);

-- AI QUOTA TRACKING
CREATE TABLE IF NOT EXISTS ai_scan_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  teacher_profile_id UUID REFERENCES teacher_profiles(id) ON DELETE SET NULL,
  scan_month DATE NOT NULL,
  scan_count INT DEFAULT 1,
  last_scan_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, scan_month)
);

-- SKILL ASSESSMENTS
CREATE TABLE IF NOT EXISTS skill_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  skill_name TEXT NOT NULL,
  proficiency_score DECIMAL(5,2),
  sample_size INT,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, subject_id, skill_name)
);

-- ACTIVITY LOG (super-admin)
CREATE TABLE IF NOT EXISTS activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
  teacher_profile_id UUID REFERENCES teacher_profiles(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  event_data JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_classes_school ON classes(school_id);
CREATE INDEX IF NOT EXISTS idx_teacher_profiles_school ON teacher_profiles(school_id);
CREATE INDEX IF NOT EXISTS idx_subjects_class ON subjects(class_id);
CREATE INDEX IF NOT EXISTS idx_subjects_teacher ON subjects(teacher_profile_id);
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_exams_student ON exams(student_id, exam_date DESC);
CREATE INDEX IF NOT EXISTS idx_exams_subject ON exams(subject_id, exam_date DESC);
CREATE INDEX IF NOT EXISTS idx_exam_questions_exam ON exam_questions(exam_id);
CREATE INDEX IF NOT EXISTS idx_homework_student_date ON homework_logs(student_id, log_date DESC);
CREATE INDEX IF NOT EXISTS idx_skills_student ON skill_assessments(student_id, subject_id);
CREATE INDEX IF NOT EXISTS idx_ai_usage_student_month ON ai_scan_usage(student_id, scan_month);
CREATE INDEX IF NOT EXISTS idx_activity_school ON activity_log(school_id, created_at DESC);

-- ROW LEVEL SECURITY
ALTER TABLE schools ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_self" ON schools;
CREATE POLICY "school_self" ON schools FOR ALL USING (id = auth.uid());

ALTER TABLE teacher_profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_profiles" ON teacher_profiles;
CREATE POLICY "school_profiles" ON teacher_profiles FOR ALL USING (school_id = auth.uid());

ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_classes" ON classes;
CREATE POLICY "school_classes" ON classes FOR ALL USING (school_id = auth.uid());

ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_subjects" ON subjects;
CREATE POLICY "school_subjects" ON subjects FOR ALL USING (
  class_id IN (SELECT id FROM classes WHERE school_id = auth.uid())
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_students" ON students;
CREATE POLICY "school_students" ON students FOR ALL USING (
  class_id IN (SELECT id FROM classes WHERE school_id = auth.uid())
);

ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_exams" ON exams;
CREATE POLICY "school_exams" ON exams FOR ALL USING (
  student_id IN (
    SELECT s.id FROM students s
    JOIN classes c ON s.class_id = c.id
    WHERE c.school_id = auth.uid()
  )
);

ALTER TABLE exam_questions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_questions" ON exam_questions;
CREATE POLICY "school_questions" ON exam_questions FOR ALL USING (
  exam_id IN (
    SELECT e.id FROM exams e
    JOIN students s ON e.student_id = s.id
    JOIN classes c ON s.class_id = c.id
    WHERE c.school_id = auth.uid()
  )
);

ALTER TABLE homework_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_homework" ON homework_logs;
CREATE POLICY "school_homework" ON homework_logs FOR ALL USING (
  student_id IN (
    SELECT s.id FROM students s
    JOIN classes c ON s.class_id = c.id
    WHERE c.school_id = auth.uid()
  )
);

ALTER TABLE ai_scan_usage ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_ai_usage" ON ai_scan_usage;
CREATE POLICY "school_ai_usage" ON ai_scan_usage FOR ALL USING (school_id = auth.uid());

ALTER TABLE skill_assessments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_skills" ON skill_assessments;
CREATE POLICY "school_skills" ON skill_assessments FOR ALL USING (
  student_id IN (
    SELECT s.id FROM students s
    JOIN classes c ON s.class_id = c.id
    WHERE c.school_id = auth.uid()
  )
);

ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "school_activity" ON activity_log;
CREATE POLICY "school_activity" ON activity_log FOR SELECT USING (school_id = auth.uid());

-- HELPER FUNCTIONS
CREATE OR REPLACE FUNCTION check_ai_quota(p_student_id UUID, p_max INT DEFAULT 10)
RETURNS BOOLEAN AS $$
DECLARE
  current_count INT;
  current_month DATE;
BEGIN
  current_month := DATE_TRUNC('month', NOW())::DATE;
  SELECT scan_count INTO current_count
  FROM ai_scan_usage
  WHERE student_id = p_student_id AND scan_month = current_month;
  RETURN COALESCE(current_count, 0) < p_max;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION increment_ai_scan(p_school_id UUID, p_student_id UUID, p_teacher_id UUID)
RETURNS INT AS $$
DECLARE
  current_month DATE;
  new_count INT;
BEGIN
  current_month := DATE_TRUNC('month', NOW())::DATE;
  INSERT INTO ai_scan_usage (school_id, student_id, teacher_profile_id, scan_month, scan_count)
  VALUES (p_school_id, p_student_id, p_teacher_id, current_month, 1)
  ON CONFLICT (student_id, scan_month)
  DO UPDATE SET
    scan_count = ai_scan_usage.scan_count + 1,
    last_scan_at = NOW(),
    teacher_profile_id = p_teacher_id
  RETURNING scan_count INTO new_count;
  RETURN new_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
