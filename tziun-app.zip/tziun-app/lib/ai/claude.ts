import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY || "" });

export interface GradedQuestion {
  question_number: number;
  question_text: string;
  student_answer: string;
  correct_answer: string;
  is_correct: boolean;
  points_awarded: number;
  max_points: number;
  ai_feedback: string;
  skill_tags: string[];
}

export interface GradingResult {
  questions: GradedQuestion[];
  total_score: number;
  max_score: number;
  bottom_line: string;
  strengths: string[];
  weaknesses: string[];
  confidence: "high" | "medium" | "low" | "uncertain";
  is_legible: boolean;
}

export interface GradingContext {
  imageBase64: string;
  subject: string;
  gradeLevel?: number;
  studentName: string;
  teacherName: string;
  teacherGender: "male" | "female";
}

export async function gradeExamWithClaude(ctx: GradingContext): Promise<GradingResult> {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error("ANTHROPIC_API_KEY not configured");
  }

  // Gender-aware Hebrew system prompt
  const teacherTitle = ctx.teacherGender === "female" ? "המורה" : "המורה";
  const verbForm = ctx.teacherGender === "female" ? "כתבה / אמרה / מצאה" : "כתב / אמר / מצא";

  const systemPrompt = `אתה עוזר הוראה מומחה לבדיקת מבחנים בעברית עבור ${ctx.subject} בכיתה ${ctx.gradeLevel || "יסודי"}.

חוקים קריטיים:
1. **אמת מוחלטת**: אם כתב היד לא ברור או אתה לא בטוח - אל תנחש. סמן את ה-confidence כ-"uncertain" וה-is_legible כ-false.
2. **התאמה מגדרית**: ${teacherTitle} שמשתמשת/משתמש במערכת היא ${ctx.teacherGender === "female" ? "אישה (השתמש בפניות בלשון נקבה)" : "גבר (השתמש בפניות בלשון זכר)"}. כל המשוב צריך להיות מנוסח בהתאם.
3. **שם התלמיד**: ${ctx.studentName}. השתמש בשמו במשוב אם רלוונטי.
4. **משוב בונה**: כתב משוב חיובי וקונקרטי - הצביעו על מה התלמיד יכול לשפר, לא רק על מה שלא נכון.

החזר JSON תקין בלבד, ללא markdown:
{
  "questions": [{
    "question_number": 1,
    "question_text": "...",
    "student_answer": "...",
    "correct_answer": "...",
    "is_correct": true,
    "points_awarded": 10,
    "max_points": 10,
    "ai_feedback": "משוב בונה ומותאם",
    "skill_tags": ["כפל", "חילוק"]
  }],
  "total_score": 85,
  "max_score": 100,
  "bottom_line": "סיכום של 2 משפטים על הביצוע",
  "strengths": ["שולט בכפל", "פתרון בעיות"],
  "weaknesses": ["מתקשה בחילוק ארוך"],
  "confidence": "high",
  "is_legible": true
}`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 4096,
    system: systemPrompt,
    messages: [{
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data: ctx.imageBase64 }},
        { type: "text", text: `בדוק את המבחן של ${ctx.studentName}. אם כתב היד לא ברור מספיק - סמן is_legible: false והחזר confidence: uncertain. החזר JSON בלבד.` }
      ]
    }]
  });

  const textBlock = message.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") throw new Error("No text response");
  const cleaned = textBlock.text.replace(/```json\s*|```\s*$/g, "").trim();
  return JSON.parse(cleaned);
}

// Quota check using DB function
export async function checkAIQuota(studentId: string): Promise<{ allowed: boolean; current: number; max: number }> {
  const supabase = createClient();
  const { data } = await supabase
    .from("ai_scan_usage")
    .select("scan_count")
    .eq("student_id", studentId)
    .gte("scan_month", new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0])
    .single();

  const current = data?.scan_count ?? 0;
  const max = 10;
  return { allowed: current < max, current, max };
}

export async function incrementAIScan(schoolId: string, studentId: string, teacherProfileId: string): Promise<number> {
  const supabase = createClient();
  const { data } = await supabase.rpc("increment_ai_scan", {
    p_school_id: schoolId,
    p_student_id: studentId,
    p_teacher_id: teacherProfileId
  });
  return data ?? 1;
}
