import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getInitials(name: string): string {
  return name.split(" ").map(w => w[0]).slice(0, 2).join("");
}

export function getAvatarColor(name: string): string {
  const colors = ["#1B4D3E", "#C9A961", "#2D7560", "#B23A48", "#0F1419"];
  const hash = name.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

export function getGradeColor(score: number): string {
  if (score >= 90) return "grade-excellent";
  if (score >= 75) return "grade-good";
  if (score >= 60) return "grade-ok";
  return "grade-poor";
}
