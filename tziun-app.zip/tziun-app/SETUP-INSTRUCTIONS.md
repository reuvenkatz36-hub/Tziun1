# 🚀 הוראות הקמה - Tziun (גרסה סופית עם AI מלא)

## 📦 מה יש בחבילה הזו

**ארכיטקטורה חדשה:**
- בית ספר אחד = login אחד עם מייל+סיסמה
- כל המורות בוחרות פרופיל אישי (Netflix-style)
- AI מובנה עם הגנת מכסה (10 סריקות לתלמיד בחודש)
- מצלמה חיה עם זיהוי איכות תמונה
- fallback ידני כשה-AI לא בטוח
- שליחה אוטומטית להורים בוואטסאפ
- Super-Admin Dashboard לפיקוח

## 🛠️ צעדי הקמה

### 1. עדכון Schema ב-Supabase

⚠️ זה ימחק את הטבלאות הישנות. אין נתונים אמיתיים, אז זה בסדר.

ב-SQL Editor של Supabase, הריצו (קודם המחיקה, אז ה-Schema):

```sql
DROP TABLE IF EXISTS exam_questions CASCADE;
DROP TABLE IF EXISTS exams CASCADE;
DROP TABLE IF EXISTS homework_logs CASCADE;
DROP TABLE IF EXISTS skill_assessments CASCADE;
DROP TABLE IF EXISTS ai_scan_usage CASCADE;
DROP TABLE IF EXISTS activity_log CASCADE;
DROP TABLE IF EXISTS students CASCADE;
DROP TABLE IF EXISTS subjects CASCADE;
DROP TABLE IF EXISTS classes CASCADE;
DROP TABLE IF EXISTS teacher_profiles CASCADE;
DROP TABLE IF EXISTS teachers CASCADE;
DROP TABLE IF EXISTS schools CASCADE;
```

ואז הדביקו את כל התוכן של `database/schema.sql` והריצו.

ודאו שיש 11 טבלאות ב-Table Editor: schools, teacher_profiles, classes, subjects, students, exams, exam_questions, homework_logs, ai_scan_usage, skill_assessments, activity_log.

### 2. הפעלת Auth ב-Supabase

ב-Authentication → Providers:
- ✅ Email - מופעל
- אין צורך ב-Google (זה login לבית ספר, לא למורה)

ב-Authentication → URL Configuration:
- **Site URL:** `https://YOUR-VERCEL-URL.vercel.app`
- **Redirect URLs:** הוסיפו `https://YOUR-VERCEL-URL.vercel.app/auth/callback`

### 3. העלאת הקוד דרך Codespaces

ב-GitHub → Tziun → Code → Codespaces → Create codespace on main

בטרמינל:

```bash
# מחיקת קבצים ישנים אם יש
rm -rf * .gitignore 2>/dev/null

# העלאת ה-ZIP דרך drag&drop של ה-VSCode (משוך לתיקייה ב-Explorer)
# או:
# unzip /workspaces/Tziun/tziun-app.zip -d .

# הזזת קבצים אם הם בתת-תיקייה
[ -d "tziun-app" ] && mv tziun-app/* tziun-app/.* . 2>/dev/null && rmdir tziun-app

# הוסיפו, commit, push
git add .
git commit -m "Tziun v2: full AI + schools + profiles + WhatsApp"
git push origin main
```

### 4. דיפלוי ב-Vercel

vercel.com → Import Tziun → Environment Variables:

```
NEXT_PUBLIC_SUPABASE_URL = https://abvtxcxcmdgpiwgcxzzx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_xxx
SUPABASE_SERVICE_ROLE_KEY = sb_secret_xxx
ANTHROPIC_API_KEY = sk-ant-xxx
NEXT_PUBLIC_APP_URL = https://YOUR-VERCEL-URL.vercel.app
SUPER_ADMIN_EMAIL = your-email@example.com
```

ה-`SUPER_ADMIN_EMAIL` הוא המייל שלך - רק אתה תוכל לגשת ל-`/admin`.

Deploy.

### 5. עדכון URL ב-Supabase

חזרו ל-Supabase → Authentication → URL Configuration והעדכנו את ה-URL של Vercel.

## 🎯 איך לבדוק

1. פתחו את ה-URL של Vercel
2. **דף נחיתה** - אמור להופיע
3. **לחצו "התחילו"** → בית ספר חדש
4. **הירשמו** עם מייל+סיסמה
5. **Onboarding בית ספר** - שם בית ספר + עיר
6. **מסך פרופילי מורים** - לחצו "הוספת פרופיל"
7. **צרו פרופיל ראשון** - שם, מין, צבע, האם מחנכת
8. **Onboarding כיתה** - שם, שכבה, תלמידים, מקצועות
9. **דשבורד** - אמור להופיע עם הגרידינג
10. **בדקו AI** - לחצו על מקצוע → "בדיקת AI אוטומטית" → צלמו/העלו תמונה של מבחן
11. **בדקו Super-Admin** - גשו ל-`/admin` עם המייל שב-`SUPER_ADMIN_EMAIL`

## 🚨 בעיות נפוצות

- **"Database error saving new user"** = לא הרצתם את ה-Schema החדש
- **"Invalid redirect URL"** = לא הוספתם את ה-Vercel URL ב-Supabase
- **"Quota exceeded"** = הגעתם ל-10 סריקות לאותו תלמיד - זה עובד נכון
- **דף לבן** = בדקו Logs ב-Vercel

## 💰 ניהול עלויות AI

- כל סריקה ≈ $0.041 (~12 אגורות)
- מכסה: 10 סריקות לתלמיד בחודש (max ~$0.41 לתלמיד)
- בית ספר עם 200 תלמידים = max $82/חודש (אם כל התלמידים יסרקו את המקסימום)
- מעקב מלא ב-`/admin`
