"use client";

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function StudentChart({ exams }: { exams: any[] }) {
  const data = [...exams].reverse().map((e, i) => ({
    name: e.exam_name || `מבחן ${i + 1}`,
    date: new Date(e.exam_date).toLocaleDateString("he-IL", { day: "numeric", month: "short" }),
    score: e.total_score
  }));

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="2 4" stroke="#E8E2D4" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#6B7280" }} reversed />
          <YAxis domain={[40, 100]} tick={{ fontSize: 11, fill: "#6B7280" }} />
          <Tooltip
            contentStyle={{ background: "white", border: "1px solid #E8E2D4", borderRadius: 10 }}
            labelStyle={{ color: "#0F1419", fontWeight: 600 }}
          />
          <Line type="monotone" dataKey="score" stroke="#1B4D3E" strokeWidth={2.5} dot={{ fill: "white", stroke: "#1B4D3E", strokeWidth: 2.5, r: 5 }} activeDot={{ r: 7, fill: "#1B4D3E" }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
