"use client";

interface Skill {
  name: string;
  score: number;
}

const MOCK_SKILLS: Skill[] = [
  { name: "חיבור וחיסור עד 1000", score: 95 },
  { name: "חילוק ארוך", score: 85 },
  { name: "לוח הכפל", score: 68 },
  { name: "חיבור שברים — מכנה משותף", score: 42 },
  { name: "בעיות מילוליות", score: 90 }
];

export default function SkillMatrix({ studentId }: { studentId: string }) {
  // In production - will fetch from skill_assessments table
  const skills = MOCK_SKILLS;

  return (
    <div className="space-y-3">
      {skills.map(s => {
        const color = s.score >= 85 ? "from-success to-green-400" :
                      s.score >= 70 ? "from-blue-700 to-blue-400" :
                      s.score >= 50 ? "from-amber to-amber-300" :
                      "from-danger to-red-400";
        const textColor = s.score >= 85 ? "text-success" :
                          s.score >= 70 ? "text-blue-700" :
                          s.score >= 50 ? "text-amber-700" :
                          "text-red-700";
        return (
          <div key={s.name}>
            <div className="flex justify-between mb-1.5 text-sm">
              <span>{s.name}</span>
              <span className={`font-bold ${textColor}`}>{s.score}%</span>
            </div>
            <div className="h-2 bg-paper-warm rounded-full overflow-hidden">
              <div className={`h-full bg-gradient-to-l ${color} transition-all duration-700`}
                style={{ width: `${s.score}%` }} />
            </div>
          </div>
        );
      })}
      <p className="text-xs text-ink-soft mt-4 text-center italic">
        🤖 המטריצה מתעדכנת אוטומטית לפי תוצאות מבחנים שמערכת ה-AI מנתחת
      </p>
    </div>
  );
}
