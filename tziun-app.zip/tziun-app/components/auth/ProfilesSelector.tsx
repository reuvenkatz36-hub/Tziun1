"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { getInitials } from "@/lib/utils";
import { Plus, User, UserCheck } from "lucide-react";

interface Profile {
  id: string;
  full_name: string;
  gender: "male" | "female";
  avatar_color: string;
  is_homeroom_teacher: boolean;
}

const AVATAR_COLORS = [
  "#1B4D3E", "#2D7560", "#C9A961", "#B23A48",
  "#5B6F7C", "#8B4513", "#6B5B95", "#88B04B"
];

export default function ProfilesSelector({ profiles, schoolId }: { profiles: Profile[]; schoolId: string }) {
  const router = useRouter();
  const supabase = createClient();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState("");
  const [newGender, setNewGender] = useState<"male" | "female">("female");
  const [newColor, setNewColor] = useState(AVATAR_COLORS[0]);
  const [isHomeroom, setIsHomeroom] = useState(false);
  const [creating, setCreating] = useState(false);

  async function selectProfile(profile: Profile) {
    // Save to local storage for the session
    localStorage.setItem("active_profile_id", profile.id);
    localStorage.setItem("active_profile_name", profile.full_name);
    localStorage.setItem("active_profile_gender", profile.gender);

    // Update last_active_at
    await supabase
      .from("teacher_profiles")
      .update({ last_active_at: new Date().toISOString() })
      .eq("id", profile.id);

    router.push("/app");
  }

  async function createProfile() {
    if (!newName.trim()) return;
    setCreating(true);
    const { data, error } = await supabase
      .from("teacher_profiles")
      .insert({
        school_id: schoolId,
        full_name: newName.trim(),
        gender: newGender,
        avatar_color: newColor,
        is_homeroom_teacher: isHomeroom
      })
      .select()
      .single();

    if (data && !error) {
      await selectProfile(data);
    }
    setCreating(false);
  }

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 justify-items-center">
        {profiles.map((p) => (
          <button
            key={p.id}
            onClick={() => selectProfile(p)}
            className="group flex flex-col items-center gap-3 cursor-pointer transition-all hover:-translate-y-1"
          >
            <div
              className="w-28 h-28 md:w-32 md:h-32 rounded-3xl flex items-center justify-center text-white font-display font-black text-4xl shadow-lg-soft group-hover:ring-4 group-hover:ring-accent/30 transition-all relative"
              style={{ background: p.avatar_color }}
            >
              {getInitials(p.full_name)}
              {p.is_homeroom_teacher && (
                <div className="absolute -top-2 -right-2 bg-gold text-white rounded-full w-7 h-7 flex items-center justify-center text-xs" title="מחנכת">
                  <UserCheck className="w-4 h-4" />
                </div>
              )}
            </div>
            <div className="text-center">
              <div className="font-semibold text-ink">{p.full_name}</div>
              <div className="text-xs text-ink-soft">
                {p.gender === "female" ? "מורה" : "מורה"}
                {p.is_homeroom_teacher && " · מחנכת"}
              </div>
            </div>
          </button>
        ))}

        {/* Add Profile button */}
        <button
          onClick={() => setShowAddModal(true)}
          className="flex flex-col items-center gap-3 cursor-pointer transition-all hover:-translate-y-1 group"
        >
          <div className="w-28 h-28 md:w-32 md:h-32 rounded-3xl border-2 border-dashed border-line bg-white flex items-center justify-center text-ink-soft group-hover:border-accent group-hover:text-accent group-hover:bg-accent-soft transition-all">
            <Plus className="w-10 h-10" />
          </div>
          <div className="text-center">
            <div className="font-semibold text-ink-soft group-hover:text-accent">הוספת פרופיל</div>
          </div>
        </button>
      </div>

      {profiles.length === 0 && (
        <p className="text-center text-ink-soft mt-12">
          זו הכניסה הראשונה לבית הספר שלכם. לחצו על "הוספת פרופיל" כדי להתחיל.
        </p>
      )}

      {/* Add Profile Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in"
          onClick={(e) => e.target === e.currentTarget && setShowAddModal(false)}>
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-lg-soft">
            <h2 className="font-display text-2xl mb-2">פרופיל חדש</h2>
            <p className="text-ink-soft text-sm mb-6">הוסיפו את הפרטים שלכם — זה ייקח דקה</p>

            <div className="mb-4">
              <label className="input-label">השם המלא שלך</label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="לדוגמה: רחל ברק"
                className="input"
                autoFocus
              />
            </div>

            <div className="mb-4">
              <label className="input-label">מין</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setNewGender("female")}
                  className={`p-4 rounded-2xl border-2 transition-all ${
                    newGender === "female" ? "border-accent bg-accent-soft" : "border-line"
                  }`}
                >
                  <div className="text-3xl mb-1">👩‍🏫</div>
                  <div className="font-semibold text-sm">מורה</div>
                </button>
                <button
                  type="button"
                  onClick={() => setNewGender("male")}
                  className={`p-4 rounded-2xl border-2 transition-all ${
                    newGender === "male" ? "border-accent bg-accent-soft" : "border-line"
                  }`}
                >
                  <div className="text-3xl mb-1">👨‍🏫</div>
                  <div className="font-semibold text-sm">מורה</div>
                </button>
              </div>
            </div>

            <div className="mb-4">
              <label className="input-label">צבע הפרופיל</label>
              <div className="flex gap-2 flex-wrap">
                {AVATAR_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNewColor(c)}
                    className={`w-10 h-10 rounded-xl transition-all ${
                      newColor === c ? "ring-4 ring-offset-2 ring-accent" : ""
                    }`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>

            <label className="flex items-center gap-3 p-4 bg-paper rounded-2xl cursor-pointer mb-6">
              <input
                type="checkbox"
                checked={isHomeroom}
                onChange={(e) => setIsHomeroom(e.target.checked)}
                className="w-5 h-5"
              />
              <div>
                <div className="font-semibold text-sm">אני מחנכת/מחנך כיתה</div>
                <div className="text-xs text-ink-soft">תקבלו גישה נוספת לכלי תעודות סוף שנה</div>
              </div>
            </label>

            <div className="flex gap-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="btn btn-secondary"
              >
                ביטול
              </button>
              <button
                onClick={createProfile}
                disabled={!newName.trim() || creating}
                className="btn btn-primary btn-block"
              >
                {creating ? "יוצר..." : "צור פרופיל ✨"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
