"use client";

import { useState } from "react";
import Link from "next/link";
import { getInitials, getAvatarColor, getGradeColor } from "@/lib/utils";

interface Student {
  id: string;
  full_name: string;
  examCount: number;
  avg: number;
}

export default function StudentSearchList({ students }: { students: Student[] }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "excellent" | "struggle">("all");

  const filtered = students
    .filter(s => s.full_name.includes(search))
    .filter(s => {
      if (filter === "excellent") return s.avg >= 90;
      if (filter === "struggle") return s.avg > 0 && s.avg < 70;
      return true;
    });

  return (
    <>
      <div className="flex gap-3 items-center mb-6 flex-wrap">
        <input
          type="search"
          placeholder="חיפוש תלמיד..."
          className="input flex-1 min-w-[200px]"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex gap-2 flex-wrap">
          {[
            { v: "all", l: "הכל" },
            { v: "excellent", l: "מצטיינים" },
            { v: "struggle", l: "דורשים עזרה" }
          ].map(p => (
            <button key={p.v}
              onClick={() => setFilter(p.v as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all border ${
                filter === p.v ? "bg-accent text-white border-accent" : "bg-white border-line hover:border-accent"
              }`}>
              {p.l}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 text-ink-soft">
          {search ? "לא נמצאו תוצאות" : "אין תלמידים להציג"}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(s => (
            <Link key={s.id} href={`/students/${s.id}`}
              className="bg-white border border-line rounded-2xl p-4 flex items-center gap-4 hover:border-accent hover:shadow-md-soft transition-all">
              <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                style={{ background: getAvatarColor(s.full_name) }}>
                {getInitials(s.full_name)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold">{s.full_name}</div>
                <div className="text-sm text-ink-soft">
                  {s.examCount > 0 ? `${s.examCount} מבחנים · ממוצע` : "אין מבחנים עדיין"}
                </div>
                {s.avg > 0 && (
                  <div className="w-24 h-1.5 bg-paper-warm rounded-full overflow-hidden mt-1">
                    <div className="h-full bg-accent" style={{ width: `${s.avg}%` }}/>
                  </div>
                )}
              </div>
              {s.avg > 0 && (
                <div className={`grade-badge ${getGradeColor(s.avg)}`}>{s.avg}</div>
              )}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
