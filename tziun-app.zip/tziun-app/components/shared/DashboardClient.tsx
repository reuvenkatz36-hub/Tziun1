"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import Topbar from "./Topbar";

interface School { school_name: string; subscription_status: string; subscription_ends_at: string; }
interface ClassRow { id: string; name: string; grade_level: number; students: any[]; subjects: any[]; }

export default function DashboardClient({ school, classes, schoolId }: { school: School; classes: ClassRow[]; schoolId: string }) {
  const router = useRouter();
  const supabase = createClient();
  const [profileName, setProfileName] = useState("");
  const [profileGender, setProfileGender] = useState<"male" | "female">("female");
  const [profileId, setProfileId] = useState("");
  const [subjects, setSubjects] = useState<any[]>([]);
  const [activeClass, setActiveClass] = useState<ClassRow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const pid = localStorage.getItem("active_profile_id");
    const pname = localStorage.getItem("active_profile_name") || "";
    const pgender = (localStorage.getItem("active_profile_gender") || "female") as "male" | "female";

    if (!pid) {
      router.push("/profiles");
      return;
    }

    setProfileId(pid);
    setProfileName(pname);
    setProfileGender(pgender);
    loadSubjects(pid);
  }, []);

  async function loadSubjects(pid: string) {
    if (classes.length === 0) {
      router.push("/onboarding/class");
      return;
    }

    const firstClass = classes[0];
    setActiveClass(firstClass);

    // Load subjects taught by this teacher profile in this class
    const { data } = await supabase
      .from("subjects")
      .select("id, name, icon, exams(count)")
      .eq("class_id", firstClass.id)
      .eq("teacher_profile_id", pid);

    setSubjects(data ?? []);
    setLoading(false);
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-ink-soft">טוען...</div>
      </div>
    );
  }

  const studentCount = activeClass?.students?.[0]?.count || 0;
  const greeting = getGreeting();
  const greetingSuffix = profileGender === "female" ? "ה" : "";
  const firstName = profileName.split(" ")[0];

  return (
    <div className="min-h-screen bg-paper">
      <Topbar
        title={activeClass?.name || school.school_name}
        subtitle={activeClass ? `${studentCount} תלמידים · ${profileName}` : profileName}
      />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Greeting */}
        <div className="relative overflow-hidden rounded-3xl mb-8 p-8 text-white shadow-md-soft" style={{
          background: "linear-gradient(135deg, #1B4D3E, #2D7560)"
        }}>
          <div className="absolute -top-1/2 -left-[10%] w-[300px] h-[300px] rounded-full bg-white/5"></div>
          <div className="relative z-10">
            <h2 className="font-display text-3xl mb-2">{greeting}, {firstName}</h2>
            <p className="opacity-90">
              {profileGender === "female" ? "ברוכה הבאה למרכז השליטה שלך" : "ברוך הבא למרכז השליטה שלך"}
            </p>
            <div className="flex gap-8 mt-6">
              <div>
                <div className="font-display text-2xl font-black">{studentCount}</div>
                <div className="text-sm opacity-85">תלמידים</div>
              </div>
              <div>
                <div className="font-display text-2xl font-black">{subjects.length}</div>
                <div className="text-sm opacity-85">המקצועות שלי</div>
              </div>
              <div>
                <div className="font-display text-2xl font-black">{classes.length}</div>
                <div className="text-sm opacity-85">כיתות</div>
              </div>
            </div>
          </div>
        </div>

        {/* Trial banner */}
        {school.subscription_status === "trial" && (
          <div className="bg-amber-soft border border-amber rounded-2xl p-4 mb-6 flex items-center justify-between">
            <div>
              <div className="font-semibold text-amber-900">🎁 תקופת ניסיון</div>
              <div className="text-sm text-amber-800">
                נותרו {daysLeft(school.subscription_ends_at)} ימים מתקופת הניסיון
              </div>
            </div>
            <Link href="/sales" className="btn btn-primary">שדרגו עכשיו</Link>
          </div>
        )}

        {/* Subjects */}
        <h2 className="font-display text-2xl mb-4">המקצועות שלי</h2>
        {subjects.length === 0 ? (
          <div className="card text-center py-12 mb-8">
            <div className="text-5xl mb-4 opacity-50">📚</div>
            <h3 className="font-semibold mb-2">עדיין לא הגדרת מקצועות</h3>
            <p className="text-ink-soft mb-4">
              {profileGender === "female" ? "הוסיפי את המקצועות שאת מלמדת" : "הוסף את המקצועות שאתה מלמד"}
            </p>
            <Link href="/onboarding/subjects" className="btn btn-primary">+ הוסף מקצוע</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-12">
            {subjects.map((s) => (
              <Link key={s.id} href={`/grade/${s.id}`}
                className="bg-white border border-line rounded-2xl p-6 text-center cursor-pointer hover:-translate-y-1 hover:shadow-md-soft hover:border-accent transition-all aspect-square flex flex-col items-center justify-center gap-2">
                <div className="text-4xl mb-1">{getSubjectIcon(s.name)}</div>
                <div className="font-semibold">{s.name}</div>
                <div className="text-xs text-ink-soft">{s.exams?.[0]?.count || 0} מבחנים</div>
              </Link>
            ))}
            <Link href="/onboarding/subjects"
              className="border-2 border-dashed border-line bg-transparent rounded-2xl p-6 text-center cursor-pointer hover:bg-paper-warm transition-all aspect-square flex flex-col items-center justify-center gap-2">
              <div className="w-12 h-12 rounded-full bg-paper-warm flex items-center justify-center text-2xl text-ink-soft">+</div>
              <div className="text-ink-soft font-medium">הוסף מקצוע</div>
            </Link>
          </div>
        )}

        {/* Quick actions */}
        <h2 className="font-display text-2xl mb-4">פעולות מהירות</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <Link href="/homework" className="flex gap-4 p-5 bg-white border border-line rounded-2xl hover:-translate-y-0.5 hover:shadow-md-soft hover:border-accent transition-all items-center">
            <div className="w-12 h-12 rounded-xl bg-accent-soft text-accent flex items-center justify-center text-xl flex-shrink-0">📓</div>
            <div>
              <h4 className="font-semibold mb-1">תיעוד שיעורי בית</h4>
              <p className="text-sm text-ink-soft">סמנו מי הגיש היום</p>
            </div>
          </Link>
          <Link href="/students" className="flex gap-4 p-5 bg-white border border-line rounded-2xl hover:-translate-y-0.5 hover:shadow-md-soft hover:border-accent transition-all items-center">
            <div className="w-12 h-12 rounded-xl bg-accent-soft text-accent flex items-center justify-center text-xl flex-shrink-0">📂</div>
            <div>
              <h4 className="font-semibold mb-1">תיקי תלמידים</h4>
              <p className="text-sm text-ink-soft">צפו בהתקדמות</p>
            </div>
          </Link>
        </div>
      </main>
    </div>
  );
}

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "בוקר טוב";
  if (h < 17) return "צהריים טובים";
  if (h < 20) return "ערב טוב";
  return "לילה טוב";
}

function getSubjectIcon(name: string): string {
  if (name.includes("מתמטיקה")) return "🔢";
  if (name.includes("עברית")) return "📖";
  if (name.includes("תנ")) return "📜";
  if (name.includes("מדע")) return "🔬";
  if (name.includes("אנגלית")) return "🌍";
  if (name.includes("גיאוגרפיה")) return "🗺️";
  return "📚";
}

function daysLeft(endsAt: string): number {
  const ms = new Date(endsAt).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 86400000));
}
