"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { ArrowRight, Users, Settings, ChevronDown } from "lucide-react";
import { getInitials, getAvatarColor } from "@/lib/utils";

interface TopbarProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  backHref?: string;
  showActions?: boolean;
}

export default function Topbar({ title, subtitle, showBack, backHref, showActions = true }: TopbarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [profileName, setProfileName] = useState("");

  useEffect(() => {
    setProfileName(localStorage.getItem("active_profile_name") || "");
  }, []);

  function switchProfile() {
    localStorage.removeItem("active_profile_id");
    localStorage.removeItem("active_profile_name");
    localStorage.removeItem("active_profile_gender");
    router.push("/profiles");
  }

  return (
    <header className="topbar">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
        {showBack ? (
          <button onClick={() => backHref ? router.push(backHref) : router.back()}
            className="flex items-center gap-2 text-ink-soft hover:text-accent transition-colors">
            <ArrowRight className="w-5 h-5" />
            <span className="font-medium">חזרה</span>
          </button>
        ) : (
          <Link href="/app" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent text-white rounded-xl flex items-center justify-center font-display font-black text-xl">צ</div>
            <div>
              <div className="font-display font-bold text-xl">{title || "ציון"}</div>
              {subtitle && <div className="text-xs text-ink-soft">{subtitle}</div>}
            </div>
          </Link>
        )}

        {showBack && title && (
          <div className="text-center">
            <div className="font-semibold">{title}</div>
            {subtitle && <div className="text-xs text-ink-soft">{subtitle}</div>}
          </div>
        )}

        {showActions && (
          <div className="flex gap-2 items-center">
            {profileName && (
              <button onClick={switchProfile}
                className="hidden md:flex items-center gap-2 px-3 py-2 border border-line rounded-xl hover:bg-paper-warm hover:border-accent transition-all text-sm">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-white font-bold text-xs"
                  style={{ background: getAvatarColor(profileName) }}>
                  {getInitials(profileName)}
                </div>
                <span>{profileName.split(" ")[0]}</span>
                <ChevronDown className="w-3 h-3 text-ink-soft" />
              </button>
            )}
            {pathname !== "/students" && (
              <Link href="/students" className="w-10 h-10 border border-line rounded-xl flex items-center justify-center hover:bg-paper-warm hover:border-accent hover:text-accent transition-all text-ink-soft" aria-label="תלמידים">
                <Users className="w-5 h-5" />
              </Link>
            )}
            {pathname !== "/settings" && (
              <Link href="/settings" className="w-10 h-10 border border-line rounded-xl flex items-center justify-center hover:bg-paper-warm hover:border-accent hover:text-accent transition-all text-ink-soft" aria-label="הגדרות">
                <Settings className="w-5 h-5" />
              </Link>
            )}
          </div>
        )}

        {showBack && !title && <div className="w-20" />}
      </div>
    </header>
  );
}
