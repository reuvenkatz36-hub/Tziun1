"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getInitials, getAvatarColor } from "@/lib/utils";

export default function SettingsClient({ school, profiles, classes }: any) {
  const router = useRouter();
  const [profileName, setProfileName] = useState("");

  if (typeof window !== "undefined" && !profileName) {
    setProfileName(localStorage.getItem("active_profile_name") || "");
  }

  function switchProfile() {
    localStorage.removeItem("active_profile_id");
    localStorage.removeItem("active_profile_name");
    localStorage.removeItem("active_profile_gender");
    router.push("/profiles");
  }

  const packageLabels: any = {
    nitzan: "🌱 ניצן",
    alon: "🌳 אלון",
    ets_hadaat: "🌟 עץ הדעת"
  };

  return (
    <>
      <div className="card mb-4">
        <h3 className="font-display text-xl mb-4">🏫 פרטי בית הספר</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <div className="text-ink-soft">שם בית הספר</div>
            <div className="font-semibold">{school?.school_name}</div>
          </div>
          <div>
            <div className="text-ink-soft">עיר</div>
            <div className="font-semibold">{school?.city || "-"}</div>
          </div>
          <div>
            <div className="text-ink-soft">מייל</div>
            <div className="font-semibold text-xs">{school?.school_email}</div>
          </div>
          <div>
            <div className="text-ink-soft">חבילה</div>
            <div className="font-semibold">{packageLabels[school?.package_tier || "nitzan"]}</div>
          </div>
        </div>
      </div>

      <div className="card mb-4">
        <h3 className="font-display text-xl mb-4">👤 הפרופיל הפעיל</h3>
        <div className="flex items-center gap-3 p-3 bg-paper rounded-xl mb-3">
          <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
            style={{ background: getAvatarColor(profileName) }}>
            {getInitials(profileName)}
          </div>
          <div className="flex-1">
            <div className="font-semibold">{profileName}</div>
            <div className="text-sm text-ink-soft">פרופיל פעיל</div>
          </div>
        </div>
        <button onClick={switchProfile} className="btn btn-secondary btn-block">
          החלף פרופיל
        </button>
      </div>

      <div className="card mb-4">
        <h3 className="font-display text-xl mb-4">👥 כל המורות ({profiles.length})</h3>
        <div className="space-y-2">
          {profiles.map((p: any) => (
            <div key={p.id} className="flex items-center gap-3 p-3 bg-paper rounded-xl">
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                style={{ background: getAvatarColor(p.full_name) }}>
                {getInitials(p.full_name)}
              </div>
              <div className="flex-1">
                <div className="font-semibold text-sm">{p.full_name}</div>
                <div className="text-xs text-ink-soft">
                  {p.is_homeroom_teacher ? "מחנכת" : "מורה"}
                  {p.last_active_at && ` · ${new Date(p.last_active_at).toLocaleDateString("he-IL")}`}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card mb-4">
        <h3 className="font-display text-xl mb-4">📚 כיתות ({classes.length})</h3>
        <div className="space-y-2">
          {classes.map((c: any) => (
            <div key={c.id} className="p-3 bg-paper rounded-xl flex justify-between items-center">
              <div>
                <div className="font-semibold">{c.name}</div>
                <div className="text-sm text-ink-soft">
                  {c.students?.[0]?.count || 0} תלמידים · {c.subjects?.[0]?.count || 0} מקצועות
                </div>
              </div>
            </div>
          ))}
          <Link href="/onboarding/class" className="btn btn-secondary btn-block mt-2">
            + הוסף כיתה
          </Link>
        </div>
      </div>

      {school?.subscription_status === "trial" && (
        <div className="card mb-4 bg-amber-soft border-amber">
          <h3 className="font-display text-lg mb-2">🎁 תקופת ניסיון</h3>
          <p className="text-sm text-amber-900 mb-3">
            תקופת הניסיון נגמרת ב-{new Date(school.subscription_ends_at).toLocaleDateString("he-IL")}
          </p>
          <Link href="/sales" className="btn btn-primary btn-block">שדרגו עכשיו</Link>
        </div>
      )}

      <div className="text-center mt-8">
        <form action="/api/auth/signout" method="post">
          <button type="submit" className="btn btn-ghost text-danger">
            🚪 התנתק מבית הספר
          </button>
        </form>
      </div>
    </>
  );
}
