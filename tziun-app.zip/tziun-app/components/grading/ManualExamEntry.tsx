"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { getInitials, getAvatarColor } from "@/lib/utils";

interface Student { id: string; full_name: string; }

export default function ManualExamEntry({ subjectId, students }: { subjectId: string; students: Student[] }) {
  const supabase = createClient();
  const router = useRouter();
  const [examName, setExamName] = useState("");
  const [examDate, setExamDate] = useState(new Date().toISOString().split("T")[0]);
  const [scores, setScores] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function updateScore(studentId: string, value: string) {
    setScores(prev => ({ ...prev, [studentId]: value }));
  }

  async function saveExams() {
    if (!examName) { setError("יש להזין שם מבחן"); return; }

    const profileId = localStorage.getItem("active_profile_id") || "";

    const examsToInsert = students
      .filter(s => scores[s.id] && scores[s.id].trim())
      .map(s => ({
        subject_id: subjectId,
        student_id: s.id,
        graded_by_profile_id: profileId,
        exam_name: examName,
        exam_date: examDate,
        total_score: Number(scores[s.id]),
        was_ai_graded: false,
        status: "graded",
        graded_at: new Date().toISOString()
      }));

    if (examsToInsert.length === 0) {
      setError("יש להזין ציון לפחות לתלמיד אחד");
      return;
    }

    setSaving(true);
    setError("");

    const { error: err } = await supabase.from("exams").insert(examsToInsert);
    if (err) {
      setError(err.message);
      setSaving(false);
    } else {
      router.push(`/grade/${subjectId}`);
    }
  }

  return (
    <>
      <div className="card mb-4">
        <div className="mb-4">
          <label className="input-label">שם המבחן</label>
          <input type="text" className="input" value={examName} onChange={e => setExamName(e.target.value)}
            placeholder="לדוגמה: מבחן פרק 6 — שטחים" />
        </div>
        <div>
          <label className="input-label">תאריך</label>
          <input type="date" className="input" value={examDate} onChange={e => setExamDate(e.target.value)} />
        </div>
      </div>

      {error && <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-700 text-sm mb-4">{error}</div>}

      <div className="card">
        <h3 className="font-semibold mb-4">הזנת ציונים ({Object.values(scores).filter(Boolean).length} / {students.length})</h3>

        <div className="space-y-2">
          {students.map(s => (
            <div key={s.id} className="flex items-center gap-3 py-3 border-b border-line last:border-0">
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                style={{ background: getAvatarColor(s.full_name) }}>
                {getInitials(s.full_name)}
              </div>
              <div className="flex-1 font-medium">{s.full_name}</div>
              <input type="number" className="input w-24 text-center" placeholder="-" max={100} min={0}
                value={scores[s.id] || ""} onChange={e => updateScore(s.id, e.target.value)} />
            </div>
          ))}
        </div>
      </div>

      <div className="sticky bottom-4 mt-6 grid grid-cols-2 gap-3 bg-paper py-4">
        <button onClick={() => router.back()} className="btn btn-secondary">ביטול</button>
        <button onClick={saveExams} disabled={saving} className="btn btn-primary">
          {saving ? "שומר..." : "✓ שמור מבחן"}
        </button>
      </div>
    </>
  );
}
