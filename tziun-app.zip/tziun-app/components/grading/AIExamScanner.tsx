"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Camera, Upload, CheckCircle, AlertCircle, Loader2, RefreshCw } from "lucide-react";
import { getInitials, getAvatarColor } from "@/lib/utils";

interface Student { id: string; full_name: string; }
type Step = "select-student" | "capture" | "review" | "fallback" | "success";

export default function AIExamScanner({ subjectId, students }: { subjectId: string; students: Student[] }) {
  const router = useRouter();
  const [step, setStep] = useState<Step>("select-student");
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [examName, setExamName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const [imageBlob, setImageBlob] = useState<Blob | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageQuality, setImageQuality] = useState<"good" | "blurry" | "checking">("checking");

  const [aiResult, setAiResult] = useState<any>(null);
  const [aiError, setAiError] = useState<string>("");
  const [loading, setLoading] = useState(false);

  const [manualScore, setManualScore] = useState("");
  const [manualNotes, setManualNotes] = useState("");

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const filtered = students.filter(s => s.full_name.includes(searchQuery));

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1080 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        startQualityCheck();
      }
    } catch (err) {
      alert("לא ניתן לפתוח מצלמה. אפשר להעלות תמונה במקום.");
    }
  }

  function stopCamera() {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  }

  function startQualityCheck() {
    const check = () => {
      if (!videoRef.current || !canvasRef.current) return;
      const v = videoRef.current;
      const c = canvasRef.current;
      const ctx = c.getContext("2d");
      if (!ctx || v.videoWidth === 0) {
        requestAnimationFrame(check);
        return;
      }

      c.width = 200;
      c.height = 200;
      ctx.drawImage(v, 0, 0, 200, 200);
      const data = ctx.getImageData(0, 0, 200, 200).data;

      // Simple blur detection: variance of luminance
      let mean = 0;
      const lumas: number[] = [];
      for (let i = 0; i < data.length; i += 4) {
        const luma = 0.299 * data[i] + 0.587 * data[i+1] + 0.114 * data[i+2];
        lumas.push(luma);
        mean += luma;
      }
      mean /= lumas.length;
      let variance = 0;
      for (const l of lumas) variance += (l - mean) ** 2;
      variance /= lumas.length;

      setImageQuality(variance > 500 ? "good" : "blurry");
      requestAnimationFrame(check);
    };
    requestAnimationFrame(check);
  }

  async function capturePhoto() {
    if (!videoRef.current || imageQuality !== "good") return;
    const v = videoRef.current;
    const c = document.createElement("canvas");
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext("2d")!.drawImage(v, 0, 0);

    c.toBlob((blob) => {
      if (blob) {
        setImageBlob(blob);
        setImagePreview(URL.createObjectURL(blob));
        stopCamera();
        runAI(blob);
      }
    }, "image/jpeg", 0.9);
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("התמונה גדולה מ-5MB");
      return;
    }
    setImageBlob(file);
    setImagePreview(URL.createObjectURL(file));
    runAI(file);
  }

  async function runAI(image: Blob) {
    if (!selectedStudent) return;
    setLoading(true);
    setAiError("");

    const profileId = localStorage.getItem("active_profile_id") || "";

    const formData = new FormData();
    formData.append("image", image, "exam.jpg");
    formData.append("studentId", selectedStudent.id);
    formData.append("subjectId", subjectId);
    formData.append("teacherProfileId", profileId);
    formData.append("examName", examName || "מבחן");

    try {
      const res = await fetch("/api/grade-exam", { method: "POST", body: formData });
      const data = await res.json();

      if (res.status === 429) {
        setAiError(data.message || "הגעת למכסת הסריקות");
        setStep("fallback");
        return;
      }

      if (!res.ok) {
        setAiError(data.error || "שגיאה");
        setStep("fallback");
        return;
      }

      if (data.needsManualFallback) {
        setAiError(data.message || "כתב היד לא ברור");
        setStep("fallback");
        return;
      }

      setAiResult(data);
      setStep("review");
    } catch (err: any) {
      setAiError(err.message || "שגיאה");
      setStep("fallback");
    } finally {
      setLoading(false);
    }
  }

  async function saveManual() {
    if (!manualScore || !selectedStudent) return;
    setLoading(true);

    const profileId = localStorage.getItem("active_profile_id") || "";

    const res = await fetch("/api/exams/manual", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        student_id: selectedStudent.id,
        subject_id: subjectId,
        graded_by_profile_id: profileId,
        exam_name: examName || "מבחן",
        total_score: Number(manualScore),
        teacher_notes: manualNotes,
        was_manual_fallback: true
      })
    });

    if (res.ok) setStep("success");
    setLoading(false);
  }

  async function confirmAI() {
    setStep("success");
  }

  useEffect(() => {
    return () => stopCamera();
  }, []);

  // === STEP 1: Select student ===
  if (step === "select-student") {
    return (
      <>
        <div className="card mb-4">
          <label className="input-label">שם המבחן (אופציונלי)</label>
          <input type="text" className="input mb-4" placeholder="לדוגמה: מבחן פרק 5"
            value={examName} onChange={e => setExamName(e.target.value)} />

          <label className="input-label">בחירת תלמיד</label>
          <input type="search" className="input mb-4" placeholder="חיפוש תלמיד..."
            value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filtered.map(s => (
              <button key={s.id} onClick={() => { setSelectedStudent(s); setStep("capture"); startCamera(); }}
                className="w-full flex items-center gap-3 p-3 bg-paper rounded-xl hover:bg-accent-soft transition-all text-right">
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                  style={{ background: getAvatarColor(s.full_name) }}>
                  {getInitials(s.full_name)}
                </div>
                <div className="flex-1 font-medium">{s.full_name}</div>
                <div className="text-accent">←</div>
              </button>
            ))}
          </div>
        </div>
      </>
    );
  }

  // === STEP 2: Capture ===
  if (step === "capture") {
    return (
      <>
        <div className="card mb-4">
          <div className="text-center mb-4">
            <div className="font-semibold">{selectedStudent?.full_name}</div>
            <div className="text-sm text-ink-soft">{examName || "מבחן"}</div>
          </div>

          <div className="relative rounded-2xl overflow-hidden bg-ink aspect-[3/4] mb-4">
            <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
            <canvas ref={canvasRef} className="hidden" />

            {/* Frame guide */}
            <div className="absolute inset-4 border-4 border-dashed rounded-2xl pointer-events-none"
              style={{ borderColor: imageQuality === "good" ? "#15803D" : imageQuality === "blurry" ? "#B23A48" : "white" }}>
            </div>

            {/* Quality indicator */}
            <div className="absolute top-4 left-4 right-4 flex justify-center">
              {imageQuality === "good" && (
                <div className="bg-green-600 text-white px-4 py-2 rounded-full font-semibold flex items-center gap-2">
                  <CheckCircle className="w-5 h-5" /> איכות טובה
                </div>
              )}
              {imageQuality === "blurry" && (
                <div className="bg-red-600 text-white px-4 py-2 rounded-full font-semibold flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" /> מטושטש
                </div>
              )}
              {imageQuality === "checking" && (
                <div className="bg-white/90 text-ink px-4 py-2 rounded-full font-semibold flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" /> בודק...
                </div>
              )}
            </div>
          </div>

          <button onClick={capturePhoto} disabled={imageQuality !== "good"}
            className="btn btn-primary btn-block btn-lg mb-2">
            <Camera className="w-5 h-5" /> צילום
          </button>

          <label className="btn btn-secondary btn-block">
            <Upload className="w-5 h-5" /> או העלאת תמונה
            <input type="file" accept="image/jpeg,image/png" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>

        <button onClick={() => { stopCamera(); setStep("select-student"); }} className="btn btn-ghost btn-block">
          ← חזרה
        </button>
      </>
    );
  }

  // === STEP 3: Loading ===
  if (loading) {
    return (
      <div className="card text-center py-12">
        {imagePreview && <img src={imagePreview} className="w-32 h-32 object-cover rounded-2xl mx-auto mb-4" />}
        <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-accent" />
        <h3 className="font-semibold mb-2">ה-AI בודק את המבחן...</h3>
        <p className="text-ink-soft text-sm">עוד 15-30 שניות</p>
      </div>
    );
  }

  // === STEP 4: Review AI result ===
  if (step === "review" && aiResult) {
    const r = aiResult.result;
    return (
      <>
        <div className="card mb-4">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="font-semibold">{selectedStudent?.full_name}</div>
              <div className="text-sm text-ink-soft">{examName || "מבחן"}</div>
            </div>
            <div className="text-left">
              <div className="font-display text-5xl font-black text-accent leading-none">{r.total_score}</div>
              <div className="text-sm text-ink-soft">ציון</div>
            </div>
          </div>

          {r.bottom_line && (
            <div className="bg-accent-soft border-r-4 border-accent rounded-xl p-3 mb-4">
              <p className="text-sm">{r.bottom_line}</p>
            </div>
          )}

          {r.strengths?.length > 0 && (
            <div className="mb-3">
              <div className="font-semibold text-success mb-1">✓ נקודות חוזק</div>
              <ul className="text-sm space-y-1">
                {r.strengths.map((s: string, i: number) => <li key={i}>· {s}</li>)}
              </ul>
            </div>
          )}

          {r.weaknesses?.length > 0 && (
            <div className="mb-4">
              <div className="font-semibold text-amber mb-1">⚠️ לחיזוק</div>
              <ul className="text-sm space-y-1">
                {r.weaknesses.map((s: string, i: number) => <li key={i}>· {s}</li>)}
              </ul>
            </div>
          )}

          <div className="text-xs text-ink-soft bg-paper p-3 rounded-xl">
            🤖 רמת ביטחון: {r.confidence === "high" ? "גבוהה" : r.confidence === "medium" ? "בינונית" : "נמוכה"}
            {aiResult.quotaRemaining !== undefined && ` · נותרו ${aiResult.quotaRemaining} סריקות לתלמיד החודש`}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => setStep("fallback")} className="btn btn-secondary">
            ערוך ידנית
          </button>
          <button onClick={confirmAI} className="btn btn-primary">
            ✓ אשר ושמור
          </button>
        </div>
      </>
    );
  }

  // === STEP 5: Manual fallback ===
  if (step === "fallback") {
    return (
      <>
        {aiError && (
          <div className="bg-amber-soft border border-amber rounded-2xl p-4 mb-4">
            <div className="flex gap-2 items-start">
              <AlertCircle className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-amber-900">{aiError}</div>
                <div className="text-sm text-amber-800 mt-1">המשך/י עם הזנה ידנית מהירה.</div>
              </div>
            </div>
          </div>
        )}

        <div className="card mb-4">
          <div className="text-center mb-4">
            <div className="font-semibold">{selectedStudent?.full_name}</div>
            <div className="text-sm text-ink-soft">{examName || "מבחן"}</div>
          </div>

          <div className="mb-4">
            <label className="input-label">ציון סופי (0-100)</label>
            <input type="number" className="input text-center text-2xl font-bold" max={100} min={0}
              value={manualScore} onChange={e => setManualScore(e.target.value)} autoFocus />
          </div>

          <div className="mb-4">
            <label className="input-label">הערות מורה (אופציונלי)</label>
            <textarea className="input" rows={3} placeholder="לדוגמה: עבודה יפה, יש לשפר חיבור שברים"
              value={manualNotes} onChange={e => setManualNotes(e.target.value)} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => setStep("select-student")} className="btn btn-secondary">
            ביטול
          </button>
          <button onClick={saveManual} disabled={!manualScore || loading} className="btn btn-primary">
            {loading ? "שומר..." : "✓ שמור"}
          </button>
        </div>
      </>
    );
  }

  // === STEP 6: Success ===
  if (step === "success") {
    return (
      <div className="card text-center py-12">
        <div className="text-6xl mb-4">🎉</div>
        <h3 className="font-display text-2xl mb-2">המבחן נשמר!</h3>
        <p className="text-ink-soft mb-6">{selectedStudent?.full_name} · {examName || "מבחן"}</p>
        <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto">
          <button onClick={() => {
            setStep("select-student");
            setSelectedStudent(null);
            setImagePreview(null);
            setAiResult(null);
            setManualScore("");
            setManualNotes("");
          }} className="btn btn-primary">
            תלמיד נוסף
          </button>
          <button onClick={() => router.push(`/grade/${subjectId}`)} className="btn btn-secondary">
            סיום
          </button>
        </div>
      </div>
    );
  }

  return null;
}
