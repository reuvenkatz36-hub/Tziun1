"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import { getInitials, getAvatarColor } from "@/lib/utils";

interface Student { id: string; full_name: string; }
interface Subject { id: string; name: string; }

export default function HomeworkLogger({ students, subjects }: { students: Student[]; subjects: Subject[] }) {
  const supabase = createClient();
  const [selectedSubject, setSelectedSubject] = useState(subjects[0]?.id || "");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [marks, setMarks] = useState<Record<string, "full" | "partial" | "missing">>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadMarks(); }, [selectedSubject, selectedDate]);

  async function loadMarks() {
    if (!selectedSubject) return;
    const { data } = await supabase
      .from("homework_logs")
      .select("student_id, status")
      .eq("subject_id", selectedSubject)
      .eq("log_date", selectedDate);

    const m: Record<string, any> = {};
    (data ?? []).forEach((r: any) => { m[r.student_id] = r.status; });
    setMarks(m);
  }

  async function toggleMark(studentId: string, status: "full" | "partial" | "missing") {
    if (!selectedSubject) return;
    setSaving(true);

    const profileId = localStorage.getItem("active_profile_id") || "";
    const newMarks = { ...marks };

    if (newMarks[studentId] === status) {
      delete newMarks[studentId];
      await supabase.from("homework_logs").delete()
        .eq("student_id", studentId).eq("subject_id", selectedSubject).eq("log_date", selectedDate);
    } else {
      newMarks[studentId] = status;
      await supabase.from("homework_logs").upsert({
        student_id: studentId,
        subject_id: selectedSubject,
        log_date: selectedDate,
        status,
        logged_by_profile_id: profileId
      }, { onConflict: "student_id,subject_id,log_date" });
    }
    setMarks(newMarks);
    setSaving(false);
  }

  const counts = {
    full: Object.values(marks).filter(s => s === "full").length,
    partial: Object.values(marks).filter(s => s === "partial").length,
    missing: Object.values(marks).filter(s => s === "missing").length
  };

  return (
    <>
      <div className="card mb-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="input-label">מקצוע</label>
            <select className="select" value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="input-label">תאריך</label>
            <input type="date" className="input" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} />
          </div>
        </div>

        <div className="flex gap-4 mt-4 pt-4 border-t border-line text-sm">
          <span><strong className="text-success">{counts.full}</strong> הגישו</span>
          <span><strong className="text-amber">{counts.partial}</strong> חלקי</span>
          <span><strong className="text-danger">{counts.missing}</strong> חסר</span>
          {saving && <span className="text-ink-soft mr-auto">שומר...</span>}
        </div>
      </div>

      <div className="space-y-2">
        {students.map(s => (
          <div key={s.id} className="flex items-center gap-3 p-3 bg-white border border-line rounded-xl">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
              style={{ background: getAvatarColor(s.full_name) }}>
              {getInitials(s.full_name)}
            </div>
            <div className="flex-1 font-medium">{s.full_name}</div>
            <div className="flex gap-2">
              <Mark active={marks[s.id] === "full"} type="full" onClick={() => toggleMark(s.id, "full")}>✓</Mark>
              <Mark active={marks[s.id] === "partial"} type="partial" onClick={() => toggleMark(s.id, "partial")}>~</Mark>
              <Mark active={marks[s.id] === "missing"} type="missing" onClick={() => toggleMark(s.id, "missing")}>✗</Mark>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function Mark({ active, type, onClick, children }: any) {
  const colors: any = {
    full: active ? "bg-success border-success text-white" : "",
    partial: active ? "bg-amber border-amber text-white" : "",
    missing: active ? "bg-danger border-danger text-white" : ""
  };
  return (
    <button onClick={onClick}
      className={`w-10 h-10 rounded-lg border-2 border-line flex items-center justify-center cursor-pointer transition-all bg-white hover:border-accent font-bold ${colors[type]}`}>
      {children}
    </button>
  );
}
