"use client";

import { useState } from "react";
import { MessageCircle } from "lucide-react";

interface Props {
  studentName: string;
  parentPhone?: string;
  reportUrl?: string;
  teacherGender: "male" | "female";
  teacherName: string;
  totalScore?: number;
  examName?: string;
}

export default function WhatsAppShareButton({
  studentName, parentPhone, reportUrl, teacherGender, teacherName, totalScore, examName
}: Props) {
  const [showPhoneInput, setShowPhoneInput] = useState(!parentPhone);
  const [phone, setPhone] = useState(parentPhone || "");

  function buildMessage(): string {
    const greeting = "שלום רב,";
    const teacherSig = teacherGender === "female"
      ? `\n\nבברכה,\n${teacherName}\nמורת ${studentName}`
      : `\n\nבברכה,\n${teacherName}\nמורה של ${studentName}`;

    let body = `שמי ${teacherName}.\n`;
    if (examName && totalScore !== undefined) {
      body += `\nמצורף דוח התקדמות של ${studentName}.\nציון אחרון ב${examName}: ${totalScore}.`;
    } else {
      body += `\nמצורף דוח התקדמות של ${studentName}.`;
    }
    if (reportUrl) body += `\n\nלצפייה בדוח המלא:\n${reportUrl}`;

    return `${greeting}\n\n${body}${teacherSig}`;
  }

  function openWhatsApp() {
    let cleanPhone = phone.replace(/[^\d]/g, "");
    if (cleanPhone.startsWith("0")) cleanPhone = "972" + cleanPhone.slice(1);
    else if (!cleanPhone.startsWith("972")) cleanPhone = "972" + cleanPhone;

    const message = encodeURIComponent(buildMessage());
    const url = `https://wa.me/${cleanPhone}?text=${message}`;
    window.open(url, "_blank");
  }

  if (showPhoneInput) {
    return (
      <div className="bg-white border border-line rounded-2xl p-4">
        <label className="input-label">מספר הורה לשליחה</label>
        <div className="flex gap-2">
          <input
            type="tel"
            placeholder="050-1234567"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="input flex-1"
            dir="ltr"
          />
          <button
            onClick={openWhatsApp}
            disabled={!phone}
            className="btn btn-primary bg-green-600 hover:bg-green-700"
            style={{ background: "#25D366" }}
          >
            <MessageCircle className="w-5 h-5" />
            שלח
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={openWhatsApp}
      className="btn btn-block text-white font-semibold flex items-center justify-center gap-2"
      style={{ background: "#25D366" }}
    >
      <MessageCircle className="w-5 h-5" />
      שלח דוח להורה בוואטסאפ
    </button>
  );
}
